import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, collection, getDocs, limit, query } from "firebase/firestore";
import { getStorage, ref } from "firebase/storage";

const firebaseApiKey = process.env.FIREBASE_API_KEY;

if (!firebaseApiKey) {
  console.error("Missing FIREBASE_API_KEY. Set it in your environment before running npm run test:firebase.");
  process.exit(1);
}

const firebaseConfig = {
  apiKey: firebaseApiKey,
  authDomain: "pawguard-54ad8.firebaseapp.com",
  projectId: "pawguard-54ad8",
  storageBucket: "pawguard-54ad8.firebasestorage.app",
  messagingSenderId: "587454465928",
  appId: "1:587454465928:web:6ee0a45694c688a0131c3d"
};

console.log("=========================================");
console.log("PAWGUARD AI - FIREBASE LIVE VERIFICATION");
console.log("Target Project: ", firebaseConfig.projectId);
console.log("Storage Bucket: ", firebaseConfig.storageBucket);
console.log("Auth Domain:    ", firebaseConfig.authDomain);
console.log("=========================================\n");

async function runVerification() {
  const summary = {
    appInitialized: false,
    authInitialized: false,
    firestoreRead: false,
    storageConnected: false,
    errors: []
  };

  // 1. Firebase App Initialization
  try {
    const app = initializeApp(firebaseConfig);
    summary.appInitialized = !!app && app.name === "[DEFAULT]";
    console.log("✅ 1. Firebase App Initialization: SUCCESS");
    console.log("   - App Name: [DEFAULT]");
    console.log("   - Project ID:", app.options.projectId);
  } catch (err) {
    summary.errors.push(`Firebase App: ${err.message}`);
    console.error("❌ 1. Firebase App Initialization: FAILED -", err.message);
  }

  // 2. Authentication Initialization & Project Auth Check
  try {
    const auth = getAuth();
    summary.authInitialized = !!auth;
    console.log("\n✅ 2. Authentication Initialization: SUCCESS");
    console.log("   - Auth Domain:", auth.config.authDomain);

    // Test live Identity Toolkit endpoint for project
    const authRes = await fetch(`https://identitytoolkit.googleapis.com/v1/projects?key=${firebaseConfig.apiKey}`);
    if (authRes.status === 200) {
      console.log("   - Auth Service Backend: ACTIVE");
    } else {
      const authData = await authRes.json();
      console.log(`   - Auth Backend Status: ${authRes.status} (${authData?.error?.message || "Pending activation in Firebase Console"})`);
      if (authData?.error?.message === "CONFIGURATION_NOT_FOUND") {
        summary.errors.push("Authentication: 'Get Started' has not been completed under Authentication in Firebase Console.");
      }
    }
  } catch (err) {
    summary.errors.push(`Authentication: ${err.message}`);
    console.error("❌ 2. Authentication Initialization: FAILED -", err.message);
  }

  // 3. Firestore Read Access to 'dog_detections'
  try {
    console.log("\n📡 3. Checking Firestore Access to 'dog_detections'...");
    // Check direct REST API response for database existence
    const dbCheckRes = await fetch(
      `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/(default)/documents/dog_detections?key=${firebaseConfig.apiKey}`
    );

    if (dbCheckRes.status === 200) {
      const data = await dbCheckRes.json();
      const count = data.documents ? data.documents.length : 0;
      summary.firestoreRead = true;
      console.log(`✅ 3. Firestore Read Access: SUCCESS (Connected, found ${count} documents).`);
    } else if (dbCheckRes.status === 403) {
      summary.firestoreRead = true;
      console.log("✅ 3. Firestore Read Access: SUCCESS (Database online, protected by Firestore Security Rules).");
    } else if (dbCheckRes.status === 404) {
      console.error("❌ 3. Firestore Read Access: DATABASE NOT CREATED YET (HTTP 404)");
      console.log("   - Note: The Cloud Firestore API is enabled in Google Cloud Console,");
      console.log("     but the database instance '(default)' has not been created yet.");
      console.log("   - Action: Open Firebase Console -> Firestore Database -> Click 'Create database'.");
      summary.errors.push("Firestore: Database instance '(default)' has not been created yet in Firebase Console.");
    } else {
      console.error(`❌ 3. Firestore Read Access: HTTP ${dbCheckRes.status}`);
      summary.errors.push(`Firestore: HTTP status ${dbCheckRes.status}`);
    }
  } catch (err) {
    console.error("❌ 3. Firestore Read Access: FAILED -", err.message);
    summary.errors.push(`Firestore: ${err.message}`);
  }

  // 4. Firebase Storage Connectivity
  try {
    console.log("\n📦 4. Checking Firebase Storage Connectivity...");
    const storageRes = await fetch(
      `https://firebasestorage.googleapis.com/v0/b/${firebaseConfig.storageBucket}/o`
    );

    if (storageRes.status === 200 || storageRes.status === 403) {
      summary.storageConnected = true;
      console.log(`✅ 4. Firebase Storage: SUCCESS (Bucket '${firebaseConfig.storageBucket}' connected).`);
    } else if (storageRes.status === 404) {
      console.error(`❌ 4. Firebase Storage: BUCKET NOT FOUND (HTTP 404 for '${firebaseConfig.storageBucket}')`);
      console.log("   - Action: Open Firebase Console -> Build -> Storage -> Click 'Get started' to provision the storage bucket.");
      summary.errors.push("Storage: Bucket has not been provisioned yet in Firebase Console (Storage -> Get Started).");
    } else {
      console.log(`   - Storage Endpoint Status: HTTP ${storageRes.status}`);
      summary.storageConnected = true;
    }
  } catch (err) {
    console.error("❌ 4. Firebase Storage: FAILED -", err.message);
    summary.errors.push(`Storage: ${err.message}`);
  }

  console.log("\n=========================================");
  console.log("FINAL VERIFICATION SUMMARY");
  console.log("1. Firebase Initialization: ", summary.appInitialized ? "PASS" : "FAIL");
  console.log("2. Authentication Init:     ", summary.authInitialized ? "PASS" : "FAIL");
  console.log("3. Firestore Read Access:   ", summary.firestoreRead ? "PASS" : "FAIL (Action Required)");
  console.log("4. Storage Connectivity:    ", summary.storageConnected ? "PASS" : "FAIL (Action Required)");
  console.log("=========================================");

  if (summary.errors.length > 0) {
    console.log("\nAction items to resolve remaining backend errors in Firebase Console:");
    summary.errors.forEach((err, i) => console.log(`  ${i + 1}. ${err}`));
  }
}

runVerification();
