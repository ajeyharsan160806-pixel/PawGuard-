// PawGuard AI - Confidence Logic Verification Test
// Tests parsing, preservation of precision, avoidance of parseInt, and percentage formatting

export const parseConfidence = (value) => {
  if (value === null || value === undefined || value === "") {
    return 0;
  }
  const num = Number(value);
  if (!Number.isFinite(num)) {
    return 0;
  }
  if (num > 1 && num <= 100) {
    return Number((num / 100).toFixed(4));
  }
  return Math.max(0, Math.min(1, num));
};

export const formatConfidencePercent = (confidence) => {
  if (confidence === null || confidence === undefined || confidence === "") {
    return "N/A";
  }
  const num = Number(confidence);
  if (!Number.isFinite(num)) {
    return "N/A";
  }
  const normalizedPercent = num >= 0 && num <= 1 ? num * 100 : num;
  const safePercent = Math.max(0, Math.min(100, Math.round(normalizedPercent)));
  return `${safePercent}%`;
};

export const isValidConfidenceInput = (value) => {
  const num = Number(value);
  return Number.isFinite(num) && num >= 0 && num <= 1;
};

console.log("=========================================");
console.log("PAWGUARD AI - CONFIDENCE VALUE TEST SUITE");
console.log("=========================================\n");

const testCases = [
  { input: 0.92, expectedNumber: 0.92, expectedDisplay: "92%" },
  { input: "0.92", expectedNumber: 0.92, expectedDisplay: "92%" },
  { input: 0.85, expectedNumber: 0.85, expectedDisplay: "85%" },
  { input: 0.50, expectedNumber: 0.50, expectedDisplay: "50%" },
  { input: 1.00, expectedNumber: 1.00, expectedDisplay: "100%" },
  { input: 0.00, expectedNumber: 0.00, expectedDisplay: "0%" },
  { input: 92, expectedNumber: 0.92, expectedDisplay: "92%" }
];

let failed = 0;

for (const tc of testCases) {
  const parsed = parseConfidence(tc.input);
  const display = formatConfidencePercent(tc.input);

  const numPass = Math.abs(parsed - tc.expectedNumber) < 0.0001;
  const dispPass = display === tc.expectedDisplay;

  if (numPass && dispPass) {
    console.log(`✅ Input: ${JSON.stringify(tc.input)} -> Parsed: ${parsed} -> Display: ${display} (PASS)`);
  } else {
    console.error(`❌ Input: ${tc.input} -> Parsed: ${parsed} (Expected: ${tc.expectedNumber}), Display: ${display} (Expected: ${tc.expectedDisplay}) (FAIL)`);
    failed++;
  }
}

console.log("\nValidation Checks:");
console.log("isValidConfidenceInput('0.92'):", isValidConfidenceInput("0.92") ? "✅ PASS" : "❌ FAIL");
console.log("isValidConfidenceInput('-46'):", !isValidConfidenceInput("-46") ? "✅ PASS (Correctly rejected negative)" : "❌ FAIL");
console.log("isValidConfidenceInput('1.5'):", !isValidConfidenceInput("1.5") ? "✅ PASS (Correctly rejected > 1)" : "❌ FAIL");

if (failed === 0) {
  console.log("\nAll confidence test cases PASSED successfully!");
  process.exit(0);
} else {
  console.error(`\n${failed} test cases FAILED!`);
  process.exit(1);
}
