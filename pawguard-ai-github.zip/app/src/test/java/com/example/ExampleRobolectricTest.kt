package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PawGuardRepository
import com.example.data.RescueStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PawGuard AI", appName)
  }

  @Test
  fun `test login and mark as rescued`() {
    val success = PawGuardRepository.login("admin", "pawguard2026")
    assertTrue(success)
    assertNotNull(PawGuardRepository.currentUser.value)

    val dogs = PawGuardRepository.detections.value
    assertTrue(dogs.isNotEmpty())

    val waitingDog = dogs.firstOrNull { it.rescueStatus == RescueStatus.WAITING }
    assertNotNull(waitingDog)

    val rescueSuccess = PawGuardRepository.markAsRescued(
      detectionId = waitingDog!!.detectionId,
      rescuerName = "Sarah Jenkins",
      organization = "PawGuard Care Network",
      date = "2026-11-08",
      time = "10:00 AM",
      notes = "Treated and safe"
    )
    assertTrue(rescueSuccess)

    val updated = PawGuardRepository.detections.value.first { it.detectionId == waitingDog.detectionId }
    assertEquals(RescueStatus.RESCUED, updated.rescueStatus)
  }
}
