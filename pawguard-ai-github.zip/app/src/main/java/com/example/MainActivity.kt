package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PawGuardRepository
import com.example.ui.components.MainTab
import com.example.ui.components.MainTopTabs
import com.example.ui.components.PawGuardHeader
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.DogMonitoringScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.SettingsAndSimulatorScreen
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingRed

enum class BottomNavDestination {
  MONITORING,
  ANALYTICS,
  NOTIFICATIONS,
  SETTINGS
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        PawGuardApp()
      }
    }
  }
}

@Composable
fun PawGuardApp() {
  val isLoggedIn by PawGuardRepository.isLoggedIn.collectAsState()
  val currentUser by PawGuardRepository.currentUser.collectAsState()
  val dogs by PawGuardRepository.detections.collectAsState()
  val devices by PawGuardRepository.devices.collectAsState()
  val notifications by PawGuardRepository.notifications.collectAsState()
  val aiConfig by PawGuardRepository.aiConfig.collectAsState()
  val demoMode by PawGuardRepository.demoMode.collectAsState()

  val unreadNotifsCount = remember(notifications) {
    notifications.count { !it.isRead }
  }

  var currentNav by remember { mutableStateOf(BottomNavDestination.MONITORING) }
  var topTab by remember { mutableStateOf(MainTab.DOG_MONITORING) }

  if (!isLoggedIn) {
    LoginScreen(
      onLoginSuccess = { username, pass ->
        PawGuardRepository.login(username, pass)
      }
    )
  } else {
    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .background(NavyDark),
      topBar = {
        Column {
          PawGuardHeader(
            user = currentUser,
            unreadNotificationsCount = unreadNotifsCount,
            onNotificationsClick = {
              currentNav = BottomNavDestination.NOTIFICATIONS
            },
            onProfileClick = {
              currentNav = BottomNavDestination.SETTINGS
            }
          )

          // Only show top segmented tabs if in primary views (Monitoring / Analytics)
          if (currentNav == BottomNavDestination.MONITORING || currentNav == BottomNavDestination.ANALYTICS) {
            MainTopTabs(
              selectedTab = topTab,
              onTabSelected = { selected ->
                topTab = selected
                currentNav = if (selected == MainTab.DOG_MONITORING) {
                  BottomNavDestination.MONITORING
                } else {
                  BottomNavDestination.ANALYTICS
                }
              }
            )
          }
        }
      },
      bottomBar = {
        NavigationBar(
          containerColor = SurfaceWhite,
          tonalElevation = 8.dp,
          modifier = Modifier.testTag("main_bottom_nav")
        ) {
          // 1. Monitoring
          NavigationBarItem(
            selected = currentNav == BottomNavDestination.MONITORING,
            onClick = {
              currentNav = BottomNavDestination.MONITORING
              topTab = MainTab.DOG_MONITORING
            },
            icon = {
              Icon(
                imageVector = Icons.Default.Pets,
                contentDescription = "Monitoring",
                modifier = Modifier.size(22.dp)
              )
            },
            label = {
              Text(
                text = "Monitoring",
                fontSize = 11.sp,
                fontWeight = if (currentNav == BottomNavDestination.MONITORING) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RoyalBlue,
              selectedTextColor = RoyalBlue,
              unselectedIconColor = TextMuted,
              unselectedTextColor = TextMuted,
              indicatorColor = SurfaceWhite
            ),
            modifier = Modifier.testTag("nav_item_monitoring")
          )

          // 2. Analytics
          NavigationBarItem(
            selected = currentNav == BottomNavDestination.ANALYTICS,
            onClick = {
              currentNav = BottomNavDestination.ANALYTICS
              topTab = MainTab.ANALYTICS
            },
            icon = {
              Icon(
                imageVector = Icons.Default.BarChart,
                contentDescription = "Analytics",
                modifier = Modifier.size(24.dp)
              )
            },
            label = {
              Text(
                text = "Analytics",
                fontSize = 11.sp,
                fontWeight = if (currentNav == BottomNavDestination.ANALYTICS) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RoyalBlue,
              selectedTextColor = RoyalBlue,
              unselectedIconColor = TextMuted,
              unselectedTextColor = TextMuted,
              indicatorColor = SurfaceWhite
            ),
            modifier = Modifier.testTag("nav_item_analytics")
          )

          // 3. Notifications
          NavigationBarItem(
            selected = currentNav == BottomNavDestination.NOTIFICATIONS,
            onClick = {
              currentNav = BottomNavDestination.NOTIFICATIONS
            },
            icon = {
              BadgedBox(
                badge = {
                  if (unreadNotifsCount > 0) {
                    Badge(containerColor = WaitingRed) {
                      Text(text = unreadNotifsCount.toString(), fontSize = 9.sp)
                    }
                  }
                }
              ) {
                Icon(
                  imageVector = Icons.Default.Notifications,
                  contentDescription = "Notifications",
                  modifier = Modifier.size(22.dp)
                )
              }
            },
            label = {
              Text(
                text = "Notifications",
                fontSize = 11.sp,
                fontWeight = if (currentNav == BottomNavDestination.NOTIFICATIONS) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RoyalBlue,
              selectedTextColor = RoyalBlue,
              unselectedIconColor = TextMuted,
              unselectedTextColor = TextMuted,
              indicatorColor = SurfaceWhite
            ),
            modifier = Modifier.testTag("nav_item_notifications")
          )

          // 4. Settings
          NavigationBarItem(
            selected = currentNav == BottomNavDestination.SETTINGS,
            onClick = {
              currentNav = BottomNavDestination.SETTINGS
            },
            icon = {
              Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                modifier = Modifier.size(22.dp)
              )
            },
            label = {
              Text(
                text = "Settings",
                fontSize = 11.sp,
                fontWeight = if (currentNav == BottomNavDestination.SETTINGS) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RoyalBlue,
              selectedTextColor = RoyalBlue,
              unselectedIconColor = TextMuted,
              unselectedTextColor = TextMuted,
              indicatorColor = SurfaceWhite
            ),
            modifier = Modifier.testTag("nav_item_settings")
          )
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .background(BackgroundLight)
      ) {
        when (currentNav) {
          BottomNavDestination.MONITORING -> {
            DogMonitoringScreen(
              dogs = dogs,
              currentUser = currentUser,
              onConfirmRescue = { dogId, rescuerName, org, date, time, notes ->
                PawGuardRepository.markAsRescued(dogId, rescuerName, org, date, time, notes)
              },
              onResetDemo = {
                PawGuardRepository.resetSampleData()
              }
            )
          }

          BottomNavDestination.ANALYTICS -> {
            AnalyticsScreen(
              summary = PawGuardRepository.getAnalyticsSummary()
            )
          }

          BottomNavDestination.NOTIFICATIONS -> {
            NotificationsScreen(
              notifications = notifications,
              onMarkAllRead = { PawGuardRepository.markAllNotificationsRead() },
              onClearAll = { PawGuardRepository.clearNotifications() }
            )
          }

          BottomNavDestination.SETTINGS -> {
            SettingsAndSimulatorScreen(
              currentUser = currentUser,
              devices = devices,
              aiConfig = aiConfig,
              demoMode = demoMode,
              onToggleDemoMode = { PawGuardRepository.setDemoMode(it) },
              onResetDemoData = { PawGuardRepository.loadInitialData() },
              onSimulateIncomingDetection = { devId, dogId, lat, lng, loc, health, conf, imgRes ->
                PawGuardRepository.addIncomingDetection(
                  deviceId = devId,
                  dogId = dogId,
                  latitude = lat,
                  longitude = lng,
                  locationName = loc,
                  healthStatus = health,
                  confidence = conf,
                  imageRes = imgRes
                )
              },
              onUpdateAiConfig = { PawGuardRepository.updateAiConfig(it) },
              onLogout = { PawGuardRepository.logout() }
            )
          }
        }
      }
    }
  }
}
