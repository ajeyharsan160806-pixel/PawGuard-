package com.example.data

enum class HealthStatus(val label: String) {
  POTENTIALLY_UNHEALTHY("Potentially Unhealthy"),
  UNCERTAIN("Uncertain"),
  HEALTHY("Healthy")
}

enum class RescueStatus(val label: String) {
  WAITING("WAITING FOR RESCUE"),
  RESCUED("RESCUED")
}

enum class NotificationType {
  NEW_DETECTION,
  RESCUE_COMPLETED,
  DEVICE_ALERT,
  SYSTEM
}

data class DogDetection(
  val detectionId: String,
  val dogId: String,
  val deviceId: String,
  val imageRes: Int? = null,
  val imageUrl: String? = null,
  val storagePath: String = "gs://pawguard-ai/detections/",
  val latitude: Double,
  val longitude: Double,
  val locationName: String,
  val capturedAt: String,
  val capturedTimestamp: Long,
  val healthStatus: HealthStatus,
  val healthConfidence: Float,
  val modelVersion: String = "1.0",
  val rescueStatus: RescueStatus = RescueStatus.WAITING,
  val rescuedBy: String? = null,
  val rescueOrganization: String? = null,
  val rescuedAt: String? = null,
  val rescueNotes: String? = null,
  val isDemo: Boolean = false
)

data class Rescuer(
  val rescuerId: String,
  val rescuerName: String,
  val organization: String,
  val contact: String,
  val totalRescued: Int = 0
)

data class User(
  val userId: String,
  val username: String,
  val displayName: String,
  val role: String, // "ADMIN" or "RESCUE_USER"
  val organization: String
)

data class HardwareDevice(
  val deviceId: String,
  val deviceName: String,
  val locationName: String,
  val latitude: Double,
  val longitude: Double,
  val deviceStatus: String, // "ONLINE", "OFFLINE"
  val batteryPercent: Int,
  val lastSeen: String
)

data class AppNotification(
  val notificationId: String,
  val title: String,
  val message: String,
  val dogId: String? = null,
  val timestamp: String,
  val type: NotificationType,
  val isRead: Boolean = false
)

data class AiModelConfig(
  val isConnected: Boolean = true,
  val endpointUrl: String = "https://api.pawguard.internal/v1/inference",
  val modelVersion: String = "Edge MobileNet-V3-DogHealth v1.0",
  val confidenceThreshold: Float = 0.85f,
  val autoAlertUnhealthy: Boolean = true
)

data class AnalyticsSummary(
  val totalUnhealthy: Int,
  val waitingForRescue: Int,
  val totalRescued: Int,
  val rescueRatePercent: Int,
  val activeDevicesCount: Int,
  val potentiallyUnhealthyCount: Int,
  val uncertainCount: Int
)

data class TrendPoint(
  val dateLabel: String,
  val count: Int
)

data class LocationStat(
  val location: String,
  val count: Int
)

data class RescuerStat(
  val rescuerName: String,
  val count: Int
)
