package com.example.data

import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object PawGuardRepository {

  private val _currentUser = MutableStateFlow<User?>(
    User(
      userId = "USR-001",
      username = "rescuer_sarah",
      displayName = "Sarah Jenkins",
      role = "ADMIN",
      organization = "PawGuard Care Network"
    )
  )
  val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

  private val _isLoggedIn = MutableStateFlow(true)
  val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

  private val _detections = MutableStateFlow<List<DogDetection>>(emptyList())
  val detections: StateFlow<List<DogDetection>> = _detections.asStateFlow()

  private val _devices = MutableStateFlow<List<HardwareDevice>>(emptyList())
  val devices: StateFlow<List<HardwareDevice>> = _devices.asStateFlow()

  private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
  val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

  private val _aiConfig = MutableStateFlow(AiModelConfig())
  val aiConfig: StateFlow<AiModelConfig> = _aiConfig.asStateFlow()

  private val _demoMode = MutableStateFlow(true)
  val demoMode: StateFlow<Boolean> = _demoMode.asStateFlow()

  init {
    loadInitialData()
  }

  fun login(username: String, pass: String): Boolean {
    if (username.isBlank() || pass.isBlank()) return false
    val role = if (username.lowercase().contains("admin")) "ADMIN" else "RESCUE_USER"
    val org = if (role == "ADMIN") "PawGuard Command Center" else "Animal Welfare & Rescue"
    val displayName = username.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    _currentUser.value = User(
      userId = "USR-${System.currentTimeMillis() % 1000}",
      username = username,
      displayName = displayName,
      role = role,
      organization = org
    )
    _isLoggedIn.value = true
    addNotification(
      title = "Session Started",
      message = "Signed in as $displayName ($role)",
      type = NotificationType.SYSTEM
    )
    return true
  }

  fun logout() {
    _currentUser.value = null
    _isLoggedIn.value = false
  }

  fun markAsRescued(
    detectionId: String,
    rescuerName: String,
    organization: String,
    date: String,
    time: String,
    notes: String?
  ): Boolean {
    val currentList = _detections.value
    val target = currentList.find { it.detectionId == detectionId } ?: return false
    if (target.rescueStatus == RescueStatus.RESCUED) return false

    val rescueTimestampStr = "$date $time"
    val updated = target.copy(
      rescueStatus = RescueStatus.RESCUED,
      rescuedBy = rescuerName.ifBlank { _currentUser.value?.displayName ?: "Rescue Volunteer" },
      rescueOrganization = organization.ifBlank { "PawGuard Rescue Team" },
      rescuedAt = rescueTimestampStr,
      rescueNotes = notes
    )

    _detections.value = currentList.map { if (it.detectionId == detectionId) updated else it }

    addNotification(
      title = "Dog Rescued!",
      message = "Dog ${target.dogId} has been successfully rescued by $rescuerName ($organization)",
      dogId = target.dogId,
      type = NotificationType.RESCUE_COMPLETED
    )
    return true
  }

  fun addIncomingDetection(
    deviceId: String,
    dogId: String,
    latitude: Double,
    longitude: Double,
    locationName: String,
    healthStatus: HealthStatus,
    confidence: Float,
    imageRes: Int? = R.drawable.dog_sample_1
  ): DogDetection {
    val now = SimpleDateFormat("MMM d, yyyy hh:mm a", Locale.US).format(Date())
    val detId = "DET-${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}-${(100..999).random()}"

    val newDetection = DogDetection(
      detectionId = detId,
      dogId = dogId,
      deviceId = deviceId,
      imageRes = imageRes,
      latitude = latitude,
      longitude = longitude,
      locationName = locationName,
      capturedAt = now,
      capturedTimestamp = System.currentTimeMillis(),
      healthStatus = healthStatus,
      healthConfidence = confidence,
      rescueStatus = RescueStatus.WAITING,
      isDemo = _demoMode.value
    )

    _detections.value = listOf(newDetection) + _detections.value

    addNotification(
      title = "New Unhealthy Dog Detected",
      message = "Dog $dogId spotted by $deviceId at $locationName (${(confidence * 100).toInt()}% confidence)",
      dogId = dogId,
      type = NotificationType.NEW_DETECTION
    )

    return newDetection
  }

  fun addNotification(title: String, message: String, dogId: String? = null, type: NotificationType) {
    val time = SimpleDateFormat("hh:mm a", Locale.US).format(Date())
    val notif = AppNotification(
      notificationId = UUID.randomUUID().toString(),
      title = title,
      message = message,
      dogId = dogId,
      timestamp = time,
      type = type,
      isRead = false
    )
    _notifications.value = listOf(notif) + _notifications.value
  }

  fun markAllNotificationsRead() {
    _notifications.value = _notifications.value.map { it.copy(isRead = true) }
  }

  fun clearNotifications() {
    _notifications.value = emptyList()
  }

  fun setDemoMode(enabled: Boolean) {
    _demoMode.value = enabled
    if (enabled) {
      loadInitialData()
    } else {
      _detections.value = _detections.value.filter { !it.isDemo }
    }
  }

  fun updateAiConfig(config: AiModelConfig) {
    _aiConfig.value = config
  }

  fun resetSampleData() {
    loadInitialData()
  }

  fun loadInitialData() {
    val sampleList = listOf(
      DogDetection(
        detectionId = "DET-20261108-001",
        dogId = "DG-001",
        deviceId = "DOG_DEVICE_01",
        imageRes = R.drawable.dog_sample_1,
        latitude = 13.0827,
        longitude = 80.2707,
        locationName = "Central Area, Chennai",
        capturedAt = "Nov 8, 2026 09:15 AM",
        capturedTimestamp = 1794149700000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.92f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.WAITING,
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-002",
        dogId = "DG-002",
        deviceId = "DOG_DEVICE_02",
        imageRes = R.drawable.dog_sample_2,
        latitude = 12.9249,
        longitude = 80.1000,
        locationName = "Tambaram, Chennai",
        capturedAt = "Nov 7, 2026 05:40 PM",
        capturedTimestamp = 1794093600000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.89f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Animal Care Team",
        rescueOrganization = "PAWS Blue Cross Unit",
        rescuedAt = "Nov 7, 2026 07:10 PM",
        rescueNotes = "Deep leg cut cleaned, bandage dressed and transferred to clinic",
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-003",
        dogId = "DG-003",
        deviceId = "DOG_DEVICE_01",
        imageRes = R.drawable.dog_sample_3,
        latitude = 13.0838,
        longitude = 80.2825,
        locationName = "Central Area, Triplicane",
        capturedAt = "Nov 8, 2026 08:30 AM",
        capturedTimestamp = 1794147000000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.94f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.WAITING,
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-004",
        dogId = "DG-004",
        deviceId = "DOG_DEVICE_03",
        imageRes = R.drawable.dog_sample_4,
        latitude = 13.0418,
        longitude = 80.2341,
        locationName = "Market Road, T. Nagar",
        capturedAt = "Nov 6, 2026 11:20 AM",
        capturedTimestamp = 1793977200000L,
        healthStatus = HealthStatus.UNCERTAIN,
        healthConfidence = 0.78f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Ravi Kumar",
        rescueOrganization = "Street Paws Foundation",
        rescuedAt = "Nov 7, 2026 10:30 AM",
        rescueNotes = "Skin dermatitis treated with topical medication",
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-005",
        dogId = "DG-005",
        deviceId = "DOG_DEVICE_04",
        imageRes = R.drawable.dog_sample_1,
        latitude = 13.0012,
        longitude = 80.2565,
        locationName = "East Colony, Adyar",
        capturedAt = "Nov 7, 2026 02:15 PM",
        capturedTimestamp = 1794081300000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.91f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Sneha Patil",
        rescueOrganization = "Blue Cross Animal Care",
        rescuedAt = "Nov 7, 2026 04:00 PM",
        rescueNotes = "Malnourished, provided food and electrolytes, recovering",
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-006",
        dogId = "DG-006",
        deviceId = "DOG_DEVICE_02",
        imageRes = R.drawable.dog_sample_2,
        latitude = 13.0732,
        longitude = 80.2609,
        locationName = "Station Area, Egmore",
        capturedAt = "Nov 8, 2026 06:45 AM",
        capturedTimestamp = 1794140700000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.88f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.WAITING,
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-007",
        dogId = "DG-007",
        deviceId = "DOG_DEVICE_01",
        imageRes = R.drawable.dog_sample_3,
        latitude = 13.0587,
        longitude = 80.2757,
        locationName = "Central Area, Marina",
        capturedAt = "Nov 5, 2026 04:10 PM",
        capturedTimestamp = 1793908200000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.95f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Ravi Kumar",
        rescueOrganization = "Street Paws Foundation",
        rescuedAt = "Nov 5, 2026 06:30 PM",
        rescueNotes = "Fractured paw stabilized and placed in foster care",
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-008",
        dogId = "DG-008",
        deviceId = "DOG_DEVICE_04",
        imageRes = R.drawable.dog_sample_4,
        latitude = 12.9998,
        longitude = 80.2678,
        locationName = "East Colony, Besant Nagar",
        capturedAt = "Nov 6, 2026 09:00 AM",
        capturedTimestamp = 1793968800000L,
        healthStatus = HealthStatus.UNCERTAIN,
        healthConfidence = 0.82f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Amit Singh",
        rescueOrganization = "Canine Care Alliance",
        rescuedAt = "Nov 6, 2026 12:00 PM",
        rescueNotes = "Dehydrated and lethargic, administered IV fluids",
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-009",
        dogId = "DG-009",
        deviceId = "DOG_DEVICE_03",
        imageRes = R.drawable.dog_sample_1,
        latitude = 13.0524,
        longitude = 80.2255,
        locationName = "Market Road, Kodambakkam",
        capturedAt = "Nov 8, 2026 10:05 AM",
        capturedTimestamp = 1794152700000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.93f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.WAITING,
        isDemo = true
      ),
      DogDetection(
        detectionId = "DET-20261108-010",
        dogId = "DG-010",
        deviceId = "DOG_DEVICE_02",
        imageRes = R.drawable.dog_sample_2,
        latitude = 13.0334,
        longitude = 80.2687,
        locationName = "Station Area, Mylapore",
        capturedAt = "Nov 7, 2026 01:25 PM",
        capturedTimestamp = 1794078300000L,
        healthStatus = HealthStatus.POTENTIALLY_UNHEALTHY,
        healthConfidence = 0.90f,
        modelVersion = "1.0",
        rescueStatus = RescueStatus.RESCUED,
        rescuedBy = "Sneha Patil",
        rescueOrganization = "Blue Cross Animal Care",
        rescuedAt = "Nov 7, 2026 03:15 PM",
        rescueNotes = "Eye conjunctivitis cleared and antibiotic eye drops provided",
        isDemo = true
      )
    )

    _detections.value = sampleList

    _devices.value = listOf(
      HardwareDevice("DOG_DEVICE_01", "Edge-Cam Central 1", "Central Area, Chennai", 13.0827, 80.2707, "ONLINE", 94, "Just now"),
      HardwareDevice("DOG_DEVICE_02", "Edge-Cam Station Hub", "Station Area, Egmore", 13.0732, 80.2609, "ONLINE", 88, "2m ago"),
      HardwareDevice("DOG_DEVICE_03", "Edge-Cam Market South", "Market Road, T. Nagar", 13.0418, 80.2341, "ONLINE", 76, "5m ago"),
      HardwareDevice("DOG_DEVICE_04", "Edge-Cam Coastal East", "East Colony, Adyar", 13.0012, 80.2565, "ONLINE", 91, "1m ago"),
      HardwareDevice("DOG_DEVICE_05", "Edge-Cam West Junction", "Koyambedu Circle", 13.0694, 80.1948, "OFFLINE", 12, "4h ago")
    )

    _notifications.value = listOf(
      AppNotification(
        notificationId = "NOTIF-1",
        title = "New Unhealthy Dog Detected",
        message = "Dog DG-001 spotted near Central Area with visible leg injury (92% confidence)",
        dogId = "DG-001",
        timestamp = "09:15 AM",
        type = NotificationType.NEW_DETECTION,
        isRead = false
      ),
      AppNotification(
        notificationId = "NOTIF-2",
        title = "Rescue Completed",
        message = "Dog DG-002 safely rescued by Animal Care Team at Tambaram",
        dogId = "DG-002",
        timestamp = "07:10 PM",
        type = NotificationType.RESCUE_COMPLETED,
        isRead = false
      ),
      AppNotification(
        notificationId = "NOTIF-3",
        title = "Hardware Heartbeat",
        message = "DOG_DEVICE_01 reported battery at 94% with optical sensor normal",
        timestamp = "08:00 AM",
        type = NotificationType.DEVICE_ALERT,
        isRead = true
      )
    )
  }

  fun getAnalyticsSummary(): AnalyticsSummary {
    val total = 48
    val waiting = _detections.value.count { it.rescueStatus == RescueStatus.WAITING }
    val rescued = total - waiting
    val rate = if (total > 0) ((rescued.toFloat() / total.toFloat()) * 100).toInt() else 0
    val activeDevs = _devices.value.count { it.deviceStatus == "ONLINE" }

    val potentiallyUnhealthyCount = (total * 0.68f).toInt()
    val uncertainCount = total - potentiallyUnhealthyCount

    return AnalyticsSummary(
      totalUnhealthy = total,
      waitingForRescue = waiting,
      totalRescued = rescued,
      rescueRatePercent = rate,
      activeDevicesCount = activeDevs,
      potentiallyUnhealthyCount = potentiallyUnhealthyCount,
      uncertainCount = uncertainCount
    )
  }
}
