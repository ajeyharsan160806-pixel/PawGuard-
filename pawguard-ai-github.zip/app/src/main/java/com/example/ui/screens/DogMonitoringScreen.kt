package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DogDetection
import com.example.data.RescueStatus
import com.example.data.User
import com.example.ui.components.DogCard
import com.example.ui.components.DogDetailsModal
import com.example.ui.components.MapView
import com.example.ui.components.RescueModal
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingRed

enum class FilterStatus {
  ALL,
  WAITING,
  RESCUED
}

@Composable
fun DogMonitoringScreen(
  dogs: List<DogDetection>,
  currentUser: User?,
  onConfirmRescue: (dogId: String, rescuerName: String, org: String, date: String, time: String, notes: String) -> Unit,
  onResetDemo: () -> Unit,
  modifier: Modifier = Modifier
) {
  var filterStatus by remember { mutableStateOf(FilterStatus.ALL) }
  var searchQuery by remember { mutableStateOf("") }
  var dateRange by remember { mutableStateOf("Date Range") }
  var dateMenuExpanded by remember { mutableStateOf(false) }

  var isMapViewOpen by remember { mutableStateOf(false) }
  var activeRescueDog by remember { mutableStateOf<DogDetection?>(null) }
  var activeDetailsDog by remember { mutableStateOf<DogDetection?>(null) }

  val filteredDogs = remember(dogs, filterStatus, searchQuery, dateRange) {
    dogs.filter { dog ->
      val matchesStatus = when (filterStatus) {
        FilterStatus.ALL -> true
        FilterStatus.WAITING -> dog.rescueStatus == RescueStatus.WAITING
        FilterStatus.RESCUED -> dog.rescueStatus == RescueStatus.RESCUED
      }
      val matchesSearch = searchQuery.isBlank() ||
        dog.dogId.contains(searchQuery, ignoreCase = true) ||
        dog.detectionId.contains(searchQuery, ignoreCase = true) ||
        dog.locationName.contains(searchQuery, ignoreCase = true) ||
        (dog.rescuedBy?.contains(searchQuery, ignoreCase = true) == true)

      matchesStatus && matchesSearch
    }
  }

  Box(modifier = modifier.fillMaxSize().background(BackgroundLight)) {
    if (isMapViewOpen) {
      MapView(
        dogs = dogs,
        onCloseMap = { isMapViewOpen = false },
        onRescueClick = { activeRescueDog = it },
        onDetailsClick = { activeDetailsDog = it }
      )
    } else {
      Column(modifier = Modifier.fillMaxSize()) {
        // Section Title: "Unhealthy Dogs Monitoring"
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceWhite)
            .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Unhealthy Dogs Monitoring",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
              )
              Text(
                text = "${filteredDogs.size} detections recorded from IoT street hardware",
                fontSize = 12.sp,
                color = TextMuted
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Filter Chips Row (All, Waiting for Rescue, Rescued, Date Range)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // All
            FilterChip(
              selected = filterStatus == FilterStatus.ALL,
              onClick = { filterStatus = FilterStatus.ALL },
              label = { Text("All", fontWeight = FontWeight.SemiBold) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = RoyalBlue,
                selectedLabelColor = SurfaceWhite
              ),
              modifier = Modifier.testTag("filter_all")
            )

            // Waiting for Rescue
            FilterChip(
              selected = filterStatus == FilterStatus.WAITING,
              onClick = { filterStatus = FilterStatus.WAITING },
              label = {
                Text(
                  "Waiting for Rescue (${dogs.count { it.rescueStatus == RescueStatus.WAITING }})",
                  fontWeight = FontWeight.SemiBold
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = WaitingRed,
                selectedLabelColor = SurfaceWhite
              ),
              modifier = Modifier.testTag("filter_waiting")
            )

            // Rescued
            FilterChip(
              selected = filterStatus == FilterStatus.RESCUED,
              onClick = { filterStatus = FilterStatus.RESCUED },
              label = {
                Text(
                  "Rescued (${dogs.count { it.rescueStatus == RescueStatus.RESCUED }})",
                  fontWeight = FontWeight.SemiBold
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = RescuedGreen,
                selectedLabelColor = SurfaceWhite
              ),
              modifier = Modifier.testTag("filter_rescued")
            )

            // Date Range Dropdown
            Box {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (dateRange != "Date Range") SkyBlueLight else Color(0xFFF1F5F9),
                modifier = Modifier
                  .testTag("filter_date_range")
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = NavyDark,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = dateRange,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = NavyDark
                  )
                  Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = NavyDark,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }

              DropdownMenu(
                expanded = dateMenuExpanded,
                onDismissRequest = { dateMenuExpanded = false }
              ) {
                DropdownMenuItem(
                  text = { Text("All Dates") },
                  onClick = {
                    dateRange = "All Dates"
                    dateMenuExpanded = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Today (Nov 8, 2026)") },
                  onClick = {
                    dateRange = "Today"
                    dateMenuExpanded = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Last 7 Days") },
                  onClick = {
                    dateRange = "Last 7 Days"
                    dateMenuExpanded = false
                  }
                )
                DropdownMenuItem(
                  text = { Text("Last 30 Days") },
                  onClick = {
                    dateRange = "Last 30 Days"
                    dateMenuExpanded = false
                  }
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Search Bar & Map View Button Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              placeholder = { Text("Search by Dog ID, location...", fontSize = 13.sp) },
              leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMuted)
              },
              trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                  IconButton(onClick = { searchQuery = "" }) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextMuted)
                  }
                }
              },
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("search_dog_input"),
              colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = BorderLight,
                focusedBorderColor = RoyalBlue
              )
            )

            // Map View Button
            Button(
              onClick = { isMapViewOpen = true },
              colors = ButtonDefaults.buttonColors(containerColor = SkyBlueLight),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .height(48.dp)
                .testTag("toggle_map_view_button")
            ) {
              Icon(
                imageVector = Icons.Default.Map,
                contentDescription = null,
                tint = RoyalBlue,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Map View",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = RoyalBlue
              )
            }
          }
        }

        // Dog Cards List
        if (filteredDogs.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.Pets,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "No dogs found matching your criteria",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextDark
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Try clearing filters or search query",
                fontSize = 12.sp,
                color = TextMuted
              )
              Spacer(modifier = Modifier.height(16.dp))
              OutlinedButton(onClick = {
                filterStatus = FilterStatus.ALL
                searchQuery = ""
                dateRange = "Date Range"
                onResetDemo()
              }) {
                Text("Reset Filters / Reload Data")
              }
            }
          }
        } else {
          LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
              .fillMaxSize()
              .testTag("dog_cards_list")
          ) {
            items(filteredDogs, key = { it.detectionId }) { dog ->
              DogCard(
                dog = dog,
                onRescueClick = { activeRescueDog = it },
                onCardClick = { activeDetailsDog = it }
              )
            }
          }
        }
      }
    }

    // Rescue Dialog
    activeRescueDog?.let { dog ->
      RescueModal(
        dog = dog,
        currentUser = currentUser,
        onDismiss = { activeRescueDog = null },
        onConfirmRescue = { detectionId, rescuerName, org, date, time, notes ->
          onConfirmRescue(detectionId, rescuerName, org, date, time, notes)
          activeRescueDog = null
        }
      )
    }

    // Details Dialog
    activeDetailsDog?.let { dog ->
      DogDetailsModal(
        dog = dog,
        onDismiss = { activeDetailsDog = null },
        onOpenRescueModal = {
          activeRescueDog = it
          activeDetailsDog = null
        }
      )
    }
  }
}
