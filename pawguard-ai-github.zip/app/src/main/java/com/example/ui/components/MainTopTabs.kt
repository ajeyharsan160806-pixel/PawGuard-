package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark

enum class MainTab(val title: String) {
  DOG_MONITORING("Dog Monitoring"),
  ANALYTICS("Analytics & Statistics")
}

@Composable
fun MainTopTabs(
  selectedTab: MainTab,
  onTabSelected: (MainTab) -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = SurfaceWhite,
    shadowElevation = 2.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .clip(RoundedCornerShape(24.dp))
        .background(Color(0xFFE2E8F0).copy(alpha = 0.6f))
        .padding(4.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Tab 1: Dog Monitoring
        val isMonitoring = selectedTab == MainTab.DOG_MONITORING
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isMonitoring) RoyalBlue else Color.Transparent)
            .clickable { onTabSelected(MainTab.DOG_MONITORING) }
            .testTag("tab_dog_monitoring")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.Pets,
              contentDescription = null,
              tint = if (isMonitoring) SurfaceWhite else NavyDark,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Dog Monitoring",
              color = if (isMonitoring) SurfaceWhite else NavyDark,
              fontSize = 14.sp,
              fontWeight = if (isMonitoring) FontWeight.Bold else FontWeight.SemiBold
            )
          }
        }

        // Tab 2: Analytics & Statistics
        val isAnalytics = selectedTab == MainTab.ANALYTICS
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isAnalytics) RoyalBlue else Color.Transparent)
            .clickable { onTabSelected(MainTab.ANALYTICS) }
            .testTag("tab_analytics_statistics")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.BarChart,
              contentDescription = null,
              tint = if (isAnalytics) SurfaceWhite else NavyDark,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Analytics & Statistics",
              color = if (isAnalytics) SurfaceWhite else NavyDark,
              fontSize = 14.sp,
              fontWeight = if (isAnalytics) FontWeight.Bold else FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}
