package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DogDetection
import com.example.data.HealthStatus
import com.example.data.RescueStatus
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RescuedGreenLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingOrange
import com.example.ui.theme.WaitingOrangeLight
import com.example.ui.theme.WaitingRed

@Composable
fun DogDetailsModal(
  dog: DogDetection,
  onDismiss: () -> Unit,
  onOpenRescueModal: (DogDetection) -> Unit
) {
  val isWaiting = dog.rescueStatus == RescueStatus.WAITING

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp)
        .testTag("dog_details_modal")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        // Image Header with Close Button and Status Badge
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(Color(0xFFE2E8F0))
        ) {
          if (dog.imageRes != null) {
            Image(
              painter = painterResource(id = dog.imageRes),
              contentDescription = "Dog ${dog.dogId}",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else if (!dog.imageUrl.isNullOrBlank()) {
            AsyncImage(
              model = dog.imageUrl,
              contentDescription = "Dog ${dog.dogId}",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else {
            Image(
              painter = painterResource(id = R.drawable.dog_sample_1),
              contentDescription = "Dog photo",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          }

          // Close button
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .padding(8.dp)
              .align(Alignment.TopEnd)
              .clip(RoundedCornerShape(20.dp))
              .background(Color.Black.copy(alpha = 0.5f))
          ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = SurfaceWhite)
          }

          // Status Badge
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isWaiting) WaitingRed else RescuedGreen,
            modifier = Modifier
              .padding(12.dp)
              .align(Alignment.BottomStart)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Icon(
                imageVector = if (isWaiting) Icons.Default.Warning else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = SurfaceWhite,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isWaiting) "WAITING FOR RESCUE" else "RESCUED",
                color = SurfaceWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Details Content
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Text(
            text = "Dog ID: ${dog.dogId}",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = "Detection ID: ${dog.detectionId}",
            fontSize = 12.sp,
            color = TextMuted
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Health Analysis Card
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (dog.healthStatus == HealthStatus.POTENTIALLY_UNHEALTHY) WaitingOrangeLight else Color(0xFFEFF6FF),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = if (dog.healthStatus == HealthStatus.POTENTIALLY_UNHEALTHY) WaitingOrange else RoyalBlue,
                modifier = Modifier.size(28.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "AI Health Classification",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = TextMuted
                )
                Text(
                  text = "${dog.healthStatus.label} (${(dog.healthConfidence.coerceIn(0f, 1f) * 100).toInt()}% confidence)",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (dog.healthStatus == HealthStatus.POTENTIALLY_UNHEALTHY) WaitingOrange else RoyalBlue
                )
                Text(
                  text = "Edge Model v${dog.modelVersion} • Screening only, not a veterinary diagnosis",
                  fontSize = 10.sp,
                  color = TextMuted
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Metadata Grid
          Text(
            text = "Telemetry & Hardware Details",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )

          Spacer(modifier = Modifier.height(8.dp))

          DetailRow(icon = Icons.Default.LocationOn, label = "Location", value = dog.locationName)
          DetailRow(icon = Icons.Default.LocationOn, label = "Coordinates", value = "${dog.latitude}, ${dog.longitude}")
          DetailRow(icon = Icons.Default.CalendarToday, label = "Captured At", value = dog.capturedAt)
          DetailRow(icon = Icons.Default.Hardware, label = "IoT Device ID", value = dog.deviceId)

          if (!isWaiting) {
            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = BorderLight)
            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = "Rescue Record",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = RescuedGreen
            )

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = RescuedGreenLight,
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "Rescued By: ${dog.rescuedBy ?: "Unknown"}",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextDark
                )
                Text(
                  text = "Organization: ${dog.rescueOrganization ?: "Community Rescuers"}",
                  fontSize = 12.sp,
                  color = TextDark
                )
                Text(
                  text = "Date & Time: ${dog.rescuedAt ?: "Recorded"}",
                  fontSize = 11.sp,
                  color = TextMuted
                )
                if (!dog.rescueNotes.isNullOrBlank()) {
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Notes: ${dog.rescueNotes}",
                    fontSize = 11.sp,
                    color = TextDark
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          if (isWaiting) {
            Button(
              onClick = {
                onDismiss()
                onOpenRescueModal(dog)
              },
              colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .testTag("modal_mark_as_rescued_btn")
            ) {
              Icon(imageVector = Icons.Default.Favorite, contentDescription = null, tint = SurfaceWhite)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Mark as Rescued", fontWeight = FontWeight.Bold, color = SurfaceWhite)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DetailRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  value: String
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Icon(imageVector = icon, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(text = "$label: ", fontSize = 12.sp, color = TextMuted)
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
  }
}
