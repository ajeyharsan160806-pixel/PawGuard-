package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DogDetection
import com.example.data.RescueStatus
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingRed

@Composable
fun MapView(
  dogs: List<DogDetection>,
  onCloseMap: () -> Unit,
  onRescueClick: (DogDetection) -> Unit,
  onDetailsClick: (DogDetection) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedDog by remember { mutableStateOf<DogDetection?>(null) }
  var statusFilter by remember { mutableStateOf<RescueStatus?>(null) }

  // Pan and Zoom states
  var scale by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  val filteredDogs = remember(dogs, statusFilter) {
    if (statusFilter == null) dogs else dogs.filter { it.rescueStatus == statusFilter }
  }

  // Chennai bounds reference
  val minLat = 12.90
  val maxLat = 13.12
  val minLng = 80.08
  val maxLng = 80.30

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFE5EEF4))
      .testTag("interactive_map_view")
  ) {
    // Map Canvas
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(Unit) {
          detectTransformGestures { _, pan, zoom, _ ->
            scale = (scale * zoom).coerceIn(0.7f, 3.5f)
            offsetX += pan.x
            offsetY += pan.y
          }
        }
        .pointerInput(filteredDogs, scale, offsetX, offsetY) {
          detectTapGestures { tapOffset ->
            // Check tap on pins
            val width = size.width
            val height = size.height

            var tapped: DogDetection? = null
            for (dog in filteredDogs) {
              val normX = ((dog.longitude - minLng) / (maxLng - minLng)).toFloat()
              val normY = (1f - ((dog.latitude - minLat) / (maxLat - minLat))).toFloat()

              val pinX = (normX * width * scale) + offsetX + (width * (1f - scale) / 2f)
              val pinY = (normY * height * scale) + offsetY + (height * (1f - scale) / 2f)

              val distSq = (tapOffset.x - pinX) * (tapOffset.x - pinX) + (tapOffset.y - pinY) * (tapOffset.y - pinY)
              if (distSq < 1600f) { // ~40px touch radius
                tapped = dog
                break
              }
            }
            selectedDog = tapped
          }
        }
    ) {
      drawMapBackground(size.width, size.height, scale, offsetX, offsetY)

      // Draw Pins
      for (dog in filteredDogs) {
        val normX = ((dog.longitude - minLng) / (maxLng - minLng)).toFloat()
        val normY = (1f - ((dog.latitude - minLat) / (maxLat - minLat))).toFloat()

        val pinX = (normX * size.width * scale) + offsetX + (size.width * (1f - scale) / 2f)
        val pinY = (normY * size.height * scale) + offsetY + (size.height * (1f - scale) / 2f)

        val isRescued = dog.rescueStatus == RescueStatus.RESCUED
        val pinColor = if (isRescued) RescuedGreen else WaitingRed
        val isSelected = selectedDog?.dogId == dog.dogId

        // Draw pin shadow & circle
        drawCircle(
          color = Color.Black.copy(alpha = 0.25f),
          radius = if (isSelected) 24f else 18f,
          center = Offset(pinX, pinY + 6f)
        )

        drawCircle(
          color = SurfaceWhite,
          radius = if (isSelected) 20f else 15f,
          center = Offset(pinX, pinY)
        )

        drawCircle(
          color = pinColor,
          radius = if (isSelected) 16f else 11f,
          center = Offset(pinX, pinY)
        )
      }
    }

    // Top Controls Bar (Back / Status filter chips)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.TopCenter)
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = SurfaceWhite,
          shadowElevation = 4.dp
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = RoyalBlue,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Dog Detection Map (${filteredDogs.size})",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              color = NavyDark
            )
          }
        }

        IconButton(
          onClick = onCloseMap,
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(SurfaceWhite)
            .testTag("close_map_button")
        ) {
          Icon(imageVector = Icons.Default.List, contentDescription = "Back to List", tint = NavyDark)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Filter chips row
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = statusFilter == null,
          onClick = { statusFilter = null },
          label = { Text("All (${dogs.size})") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalBlue,
            selectedLabelColor = SurfaceWhite
          )
        )

        FilterChip(
          selected = statusFilter == RescueStatus.WAITING,
          onClick = { statusFilter = RescueStatus.WAITING },
          label = { Text("Waiting (${dogs.count { it.rescueStatus == RescueStatus.WAITING }})") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = WaitingRed,
            selectedLabelColor = SurfaceWhite
          )
        )

        FilterChip(
          selected = statusFilter == RescueStatus.RESCUED,
          onClick = { statusFilter = RescueStatus.RESCUED },
          label = { Text("Rescued (${dogs.count { it.rescueStatus == RescueStatus.RESCUED }})") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RescuedGreen,
            selectedLabelColor = SurfaceWhite
          )
        )
      }
    }

    // Reset center button
    FloatingActionButton(
      onClick = {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
      },
      containerColor = SurfaceWhite,
      contentColor = RoyalBlue,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = if (selectedDog != null) 170.dp else 24.dp, end = 16.dp)
        .size(46.dp)
    ) {
      Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Center Map")
    }

    // Selected Dog Bottom Popup Card
    selectedDog?.let { dog ->
      val isWaiting = dog.rescueStatus == RescueStatus.WAITING
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.BottomCenter)
          .padding(16.dp)
          .testTag("map_dog_preview_card")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Thumbnail
          Box(
            modifier = Modifier
              .size(64.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFE2E8F0))
          ) {
            Image(
              painter = painterResource(id = dog.imageRes ?: R.drawable.dog_sample_1),
              contentDescription = null,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "Dog ID: ${dog.dogId}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextDark
              )
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (isWaiting) WaitingRed else RescuedGreen
              ) {
                Text(
                  text = if (isWaiting) "WAITING" else "RESCUED",
                  color = SurfaceWhite,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Text(
              text = dog.locationName,
              fontSize = 11.sp,
              color = TextMuted,
              maxLines = 1
            )
            Text(
              text = "Captured: ${dog.capturedAt}",
              fontSize = 10.sp,
              color = TextMuted
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (isWaiting) {
                Button(
                  onClick = { onRescueClick(dog) },
                  colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Icon(imageVector = Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(12.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Rescue", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }

              Button(
                onClick = { onDetailsClick(dog) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
              ) {
                Text("Details", fontSize = 11.sp, color = TextDark)
              }
            }
          }

          IconButton(
            onClick = { selectedDog = null },
            modifier = Modifier.size(28.dp)
          ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close Preview", tint = TextMuted)
          }
        }
      }
    }
  }
}

private fun DrawScope.drawMapBackground(
  width: Float,
  height: Float,
  scale: Float,
  panX: Float,
  panY: Float
) {
  // Water / Bay of Bengal on right side
  val waterPath = Path().apply {
    moveTo(width * 0.85f * scale + panX, 0f)
    lineTo(width, 0f)
    lineTo(width, height)
    lineTo(width * 0.82f * scale + panX, height)
    close()
  }
  drawPath(waterPath, Color(0xFFBAE6FD))

  // Urban Grid streets lines
  val gridColor = Color(0xFFCBD5E1).copy(alpha = 0.7f)
  val mainRoadColor = Color(0xFFFFFFFF)

  val step = 80f * scale
  var x = panX % step
  while (x < width) {
    drawLine(
      color = gridColor,
      start = Offset(x, 0f),
      end = Offset(x, height),
      strokeWidth = 2f * scale
    )
    x += step
  }

  var y = panY % step
  while (y < height) {
    drawLine(
      color = gridColor,
      start = Offset(0f, y),
      end = Offset(width, y),
      strokeWidth = 2f * scale
    )
    y += step
  }

  // Major Highways
  drawLine(
    color = mainRoadColor,
    start = Offset(0f, height * 0.35f * scale + panY),
    end = Offset(width, height * 0.45f * scale + panY),
    strokeWidth = 6f * scale
  )
  drawLine(
    color = mainRoadColor,
    start = Offset(width * 0.4f * scale + panX, 0f),
    end = Offset(width * 0.5f * scale + panX, height),
    strokeWidth = 6f * scale
  )
}
