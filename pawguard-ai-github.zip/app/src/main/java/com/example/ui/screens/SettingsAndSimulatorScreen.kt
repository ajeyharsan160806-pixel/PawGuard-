package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AiModelConfig
import com.example.data.HardwareDevice
import com.example.data.HealthStatus
import com.example.data.User
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RescuedGreenLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingOrange
import com.example.ui.theme.WaitingRed

@Composable
fun SettingsAndSimulatorScreen(
  currentUser: User?,
  devices: List<HardwareDevice>,
  aiConfig: AiModelConfig,
  demoMode: Boolean,
  onToggleDemoMode: (Boolean) -> Unit,
  onResetDemoData: () -> Unit,
  onSimulateIncomingDetection: (
    deviceId: String,
    dogId: String,
    lat: Double,
    lng: Double,
    location: String,
    health: HealthStatus,
    confidence: Float,
    imageRes: Int
  ) -> Unit,
  onUpdateAiConfig: (AiModelConfig) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  var confidenceThreshold by remember { mutableFloatStateOf(aiConfig.confidenceThreshold) }
  var simulationSuccessMsg by remember { mutableStateOf<String?>(null) }

  // Simulator parameters
  var simDeviceId by remember { mutableStateOf("DOG_DEVICE_01") }
  var simDogId by remember { mutableStateOf("DG-105") }
  var simLocation by remember { mutableStateOf("Marina Beach Road, Chennai") }
  var simLat by remember { mutableStateOf("13.0498") }
  var simLng by remember { mutableStateOf("80.2810") }
  var simConfidence by remember { mutableFloatStateOf(0.93f) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundLight)
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("settings_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. User Profile Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = CircleShape,
          color = NavyDark,
          modifier = Modifier.size(50.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = SurfaceWhite, modifier = Modifier.size(28.dp))
          }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = currentUser?.displayName ?: "Guest User",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )
          Text(
            text = "Role: ${currentUser?.role ?: "RESCUE_USER"} • ${currentUser?.organization ?: "PawGuard Network"}",
            fontSize = 12.sp,
            color = TextMuted
          )
        }

        OutlinedButton(
          onClick = onLogout,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = WaitingRed),
          modifier = Modifier.testTag("logout_button")
        ) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Logout", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 2. Demo Mode Controls
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Engineering, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(text = "Demo Mode Controls", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NavyDark)
              Text(text = "10 preconfigured realistic sample detections", fontSize = 11.sp, color = TextMuted)
            }
          }

          Switch(
            checked = demoMode,
            onCheckedChange = { onToggleDemoMode(it) },
            colors = SwitchDefaults.colors(checkedThumbColor = RoyalBlue, checkedTrackColor = SkyBlueLight),
            modifier = Modifier.testTag("demo_mode_switch")
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = {
              onToggleDemoMode(true)
              onResetDemoData()
            },
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f).testTag("load_demo_data_btn")
          ) {
            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("LOAD DEMO DATA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = { onToggleDemoMode(false) },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f).testTag("clear_demo_data_btn")
          ) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = WaitingRed, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("CLEAR DEMO DATA", fontSize = 11.sp, color = WaitingRed)
          }
        }
      }
    }

    // 3. IoT Street Hardware Simulator (POST /api/detections)
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Sensors, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(text = "IoT Street Hardware Simulator", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NavyDark)
            Text(text = "Simulates incoming POST /api/detections from street camera", fontSize = 11.sp, color = TextMuted)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (simulationSuccessMsg != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = RescuedGreenLight,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(10.dp)
            ) {
              Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = RescuedGreen, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = simulationSuccessMsg ?: "", fontSize = 11.sp, color = RescuedGreen, fontWeight = FontWeight.Bold)
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = simDeviceId,
            onValueChange = { simDeviceId = it },
            label = { Text("Device ID") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp)
          )
          OutlinedTextField(
            value = simDogId,
            onValueChange = { simDogId = it },
            label = { Text("Dog ID") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = simLocation,
          onValueChange = { simLocation = it },
          label = { Text("Location Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "AI Confidence Score: ${(simConfidence * 100).toInt()}%", fontSize = 12.sp, color = TextDark)
        Slider(
          value = simConfidence,
          onValueChange = { simConfidence = it },
          valueRange = 0.5f..1.0f,
          colors = SliderDefaults.colors(thumbColor = RoyalBlue, activeTrackColor = RoyalBlue)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Button(
          onClick = {
            val lat = simLat.toDoubleOrNull() ?: 13.0827
            val lng = simLng.toDoubleOrNull() ?: 80.2707
            val sampleRes = listOf(R.drawable.dog_sample_1, R.drawable.dog_sample_2, R.drawable.dog_sample_3, R.drawable.dog_sample_4).random()
            onSimulateIncomingDetection(
              simDeviceId,
              simDogId,
              lat,
              lng,
              simLocation,
              HealthStatus.POTENTIALLY_UNHEALTHY,
              simConfidence,
              sampleRes
            )
            simulationSuccessMsg = "Success: Detection $simDogId received & saved! Notification alert dispatched."
            simDogId = "DG-${(106..999).random()}"
          },
          colors = ButtonDefaults.buttonColors(containerColor = NavyDark),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth().height(44.dp).testTag("trigger_iot_detection_btn")
        ) {
          Icon(imageVector = Icons.Default.AddAlert, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Simulate Street Camera Trigger", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 4. AI Model Integration Configuration
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "AI Model Integration", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NavyDark)
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = RescuedGreenLight
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(RescuedGreen))
              Spacer(modifier = Modifier.width(4.dp))
              Text(text = "AI MODEL CONNECTED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RescuedGreen)
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "Pipeline: Camera Image ➔ Dog Detection ➔ Image Crop ➔ Health Classification ➔ Cloud Decision",
          fontSize = 11.sp,
          color = TextMuted,
          lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(text = "Model Version: ${aiConfig.modelVersion}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
        Text(text = "Inference Endpoint: ${aiConfig.endpointUrl}", fontSize = 11.sp, color = TextMuted)

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "Upload Threshold: ${(confidenceThreshold * 100).toInt()}%", fontSize = 12.sp, color = TextDark)
        Slider(
          value = confidenceThreshold,
          onValueChange = {
            confidenceThreshold = it
            onUpdateAiConfig(aiConfig.copy(confidenceThreshold = it))
          },
          valueRange = 0.6f..0.98f,
          colors = SliderDefaults.colors(thumbColor = RoyalBlue, activeTrackColor = RoyalBlue)
        )
      }
    }

    // 5. Active Hardware Devices List
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Hardware, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Street Hardware Units (${devices.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NavyDark)
        }

        Spacer(modifier = Modifier.height(10.dp))

        devices.forEach { dev ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "${dev.deviceId} • ${dev.deviceName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextDark)
              Text(text = "${dev.locationName} • Last seen ${dev.lastSeen}", fontSize = 11.sp, color = TextMuted)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.BatteryFull,
                contentDescription = null,
                tint = if (dev.batteryPercent > 20) RescuedGreen else WaitingRed,
                modifier = Modifier.size(16.dp)
              )
              Text(text = "${dev.batteryPercent}%", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (dev.deviceStatus == "ONLINE") RescuedGreenLight else Color(0xFFFEE2E2)
              ) {
                Text(
                  text = dev.deviceStatus,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (dev.deviceStatus == "ONLINE") RescuedGreen else WaitingRed,
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }
          }
          HorizontalDivider(color = BorderLight.copy(alpha = 0.5f))
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))
  }
}
