package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlue
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingRed

@Composable
fun LoginScreen(
  onLoginSuccess: (username: String, role: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var passwordVisible by remember { mutableStateOf(false) }
  var rememberMe by remember { mutableStateOf(true) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF0F3260))
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
    ) {
      // Top Hero with Dog Image & Branding
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
      ) {
        Image(
          painter = painterResource(id = R.drawable.dog_hero_header),
          contentDescription = "PawGuard Hero Dog",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Black.copy(alpha = 0.35f),
                  Color.Transparent,
                  NavyDark.copy(alpha = 0.85f)
                )
              )
            )
        )

        // Top Brand Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .padding(top = 28.dp, start = 20.dp)
            .align(Alignment.TopStart)
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_pawguard_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(52.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "PawGuard AI",
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold,
              color = SurfaceWhite
            )
            Text(
              text = "Monitor • Protect • Rescue",
              fontSize = 12.sp,
              color = SurfaceWhite.copy(alpha = 0.9f)
            )
          }
        }

        // Sub-motto
        Text(
          text = "A kinder city\nfor stray dogs  💙",
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = SurfaceWhite,
          modifier = Modifier
            .padding(start = 24.dp, bottom = 20.dp)
            .align(Alignment.BottomStart)
        )
      }

      // Card Container (White)
      Surface(
        color = SurfaceWhite,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f, fill = false)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Welcome Back Header
          Surface(
            shape = CircleShape,
            color = Color(0xFF0F3260),
            modifier = Modifier.size(54.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = SurfaceWhite,
                modifier = Modifier.size(32.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Welcome Back!",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )

          Text(
            text = "Sign in to access PawGuard AI",
            fontSize = 13.sp,
            color = TextMuted
          )

          Spacer(modifier = Modifier.height(20.dp))

          // Error Message
          if (errorMessage != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFFEE2E2),
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
            ) {
              Text(
                text = errorMessage ?: "",
                color = WaitingRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          // Username Field
          OutlinedTextField(
            value = username,
            onValueChange = {
              username = it
              errorMessage = null
            },
            label = { Text("Username") },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = RoyalBlue)
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("login_username_input"),
            colors = OutlinedTextFieldDefaults.colors(
              unfocusedBorderColor = BorderLight,
              focusedBorderColor = RoyalBlue
            )
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Password Field
          OutlinedTextField(
            value = password,
            onValueChange = {
              password = it
              errorMessage = null
            },
            label = { Text("Password") },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = RoyalBlue)
            },
            trailingIcon = {
              IconButton(onClick = { passwordVisible = !passwordVisible }) {
                Icon(
                  imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                  contentDescription = "Toggle password visibility",
                  tint = TextMuted
                )
              }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("login_password_input"),
            colors = OutlinedTextFieldDefaults.colors(
              unfocusedBorderColor = BorderLight,
              focusedBorderColor = RoyalBlue
            )
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Remember Me & Forgot Password
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Checkbox(
                checked = rememberMe,
                onCheckedChange = { rememberMe = it },
                colors = CheckboxDefaults.colors(checkedColor = RoyalBlue),
                modifier = Modifier.testTag("remember_me_checkbox")
              )
              Text(text = "Remember Me", fontSize = 12.sp, color = TextDark)
            }

            Text(
              text = "Forgot Password?",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = RoyalBlue,
              modifier = Modifier.clickable {
                errorMessage = "Please contact your PawGuard system administrator to reset credentials."
              }
            )
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Big Login Button
          Button(
            onClick = {
              if (username.isBlank() || password.isBlank()) {
                errorMessage = "Please enter both username and password"
              } else {
                onLoginSuccess(username, if (username.lowercase().contains("admin")) "ADMIN" else "RESCUE_USER")
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NavyDark),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("login_submit_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = null,
              tint = SurfaceWhite,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Login",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = SurfaceWhite
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Spacer(modifier = Modifier.height(24.dp))

          // Feature Highlights (3 columns matching screenshot)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            FeatureHighlight(icon = Icons.Default.Search, title = "Detect\nUnhealthy Dogs")
            FeatureHighlight(icon = Icons.Default.LocationOn, title = "Track\nLocations")
            FeatureHighlight(icon = Icons.Default.Favorite, title = "Enable\nRescue")
          }

          Spacer(modifier = Modifier.height(24.dp))

          // Bottom Slogan
          Text(
            text = "Together for a safer,\nkinder world  🐾",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = NavyDark.copy(alpha = 0.8f),
            lineHeight = 18.sp
          )
        }
      }
    }
  }
}

@Composable
private fun FeatureHighlight(icon: ImageVector, title: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Surface(
      shape = CircleShape,
      color = SkyBlueLight,
      modifier = Modifier.size(46.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(imageVector = icon, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(22.dp))
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = title,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      color = TextDark,
      lineHeight = 14.sp
    )
  }
}
