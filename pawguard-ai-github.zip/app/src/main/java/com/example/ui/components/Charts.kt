package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyticsSummary
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.PurpleBar
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingOrange
import com.example.ui.theme.WaitingRed

@Composable
fun SummaryCardsGrid(
  summary: AnalyticsSummary,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Card 1: Total Unhealthy Dogs Detected (Navy)
      MetricCard(
        title = "Total Unhealthy\nDogs Detected",
        value = summary.totalUnhealthy.toString(),
        icon = Icons.Default.Pets,
        containerColor = NavyDark,
        contentColor = SurfaceWhite,
        modifier = Modifier.weight(1f).testTag("stat_card_total")
      )

      // Card 2: Waiting for Rescue (Orange)
      MetricCard(
        title = "Waiting for\nRescue",
        value = summary.waitingForRescue.toString(),
        icon = Icons.Default.Schedule,
        containerColor = WaitingOrange,
        contentColor = SurfaceWhite,
        modifier = Modifier.weight(1f).testTag("stat_card_waiting")
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Card 3: Total Rescued (Green)
      MetricCard(
        title = "Total\nRescued",
        value = summary.totalRescued.toString(),
        icon = Icons.Default.CheckCircle,
        containerColor = RescuedGreen,
        contentColor = SurfaceWhite,
        modifier = Modifier.weight(1f).testTag("stat_card_rescued")
      )

      // Card 4: Rescue Rate (White with circular gauge)
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .weight(1f)
          .height(130.dp)
          .testTag("stat_card_rate")
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier.size(62.dp),
            contentAlignment = Alignment.Center
          ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
              val strokeWidth = 8.dp.toPx()
              // Background track
              drawArc(
                color = Color(0xFFE2E8F0),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
              )
              // Progress arc
              val sweep = 360f * (summary.rescueRatePercent / 100f)
              drawArc(
                color = RescuedGreen,
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
              )
            }
            Text(
              text = "${summary.rescueRatePercent}%",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = TextDark
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Rescue Rate",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextDark
          )
        }
      }
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  icon: ImageVector,
  containerColor: Color,
  contentColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.height(130.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween,
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        shape = CircleShape,
        color = SurfaceWhite.copy(alpha = 0.2f),
        modifier = Modifier.size(34.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Text(
        text = value,
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold,
        color = contentColor
      )

      Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = contentColor.copy(alpha = 0.9f),
        lineHeight = 14.sp
      )
    }
  }
}

// Chart 1: Dog Detection Trend (Line Chart)
@Composable
fun DetectionTrendChart(modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("chart_detection_trend")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Timeline,
            contentDescription = null,
            tint = RoyalBlue,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Dog Detection Trend",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(RoyalBlue)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Unhealthy Dogs",
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Trend Line Chart with Bezier curve
      val dataPoints = listOf(10f, 15f, 25f, 13f, 21f)
      val dateLabels = listOf("Nov 2", "Nov 8", "Nov 14", "Nov 20", "Nov 30")

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width - 70f
          val h = size.height - 40f
          val startX = 40f

          // Grid lines and Y labels
          val ySteps = listOf(0, 10, 20, 30)
          for (yVal in ySteps) {
            val yPos = h - (yVal / 30f * h)
            drawLine(
              color = Color(0xFFE2E8F0),
              start = Offset(startX, yPos),
              end = Offset(size.width - 20f, yPos),
              strokeWidth = 1.dp.toPx()
            )
          }

          // Calculate points
          val points = dataPoints.mapIndexed { index, value ->
            val px = startX + (index.toFloat() / (dataPoints.size - 1)) * w
            val py = h - (value / 30f * h)
            Offset(px, py)
          }

          // Fill path under line
          val fillPath = Path().apply {
            moveTo(points.first().x, h)
            lineTo(points.first().x, points.first().y)
            for (i in 0 until points.size - 1) {
              val p0 = points[i]
              val p1 = points[i + 1]
              val cx = (p0.x + p1.x) / 2
              cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
            }
            lineTo(points.last().x, h)
            close()
          }

          drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
              colors = listOf(RoyalBlue.copy(alpha = 0.25f), RoyalBlue.copy(alpha = 0.02f)),
              startY = 0f,
              endY = h
            )
          )

          // Stroke line
          val strokePath = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 0 until points.size - 1) {
              val p0 = points[i]
              val p1 = points[i + 1]
              val cx = (p0.x + p1.x) / 2
              cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
            }
          }

          drawPath(
            path = strokePath,
            color = RoyalBlue,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
          )

          // Point dots
          for (pt in points) {
            drawCircle(color = SurfaceWhite, radius = 5.dp.toPx(), center = pt)
            drawCircle(color = RoyalBlue, radius = 3.dp.toPx(), center = pt)
          }
        }

        // X labels overlay
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter)
            .padding(start = 24.dp, end = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          for (label in dateLabels) {
            Text(text = label, fontSize = 10.sp, color = TextMuted)
          }
        }
      }
    }
  }
}

// Chart 2: Rescue Statistics (Bar Chart)
@Composable
fun RescueStatisticsChart(waiting: Int = 12, rescued: Int = 36, modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("chart_rescue_statistics")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.ShowChart,
            contentDescription = null,
            tint = NavyDark,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Rescue Statistics", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDark)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(WaitingOrange))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "Waiting", fontSize = 10.sp, color = TextMuted)
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(RescuedGreen))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "Rescued", fontSize = 10.sp, color = TextMuted)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bar Canvas
      Box(modifier = Modifier.fillMaxWidth().height(120.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val maxVal = 40f
          val h = size.height - 24f
          val w = size.width

          // Horizontal grid
          for (step in listOf(0, 10, 20, 30, 40)) {
            val y = h - (step / maxVal * h)
            drawLine(color = Color(0xFFE2E8F0), start = Offset(24f, y), end = Offset(w, y), strokeWidth = 1f)
          }

          val barWidth = 60f
          // Waiting Bar
          val waitH = (waiting / maxVal) * h
          drawRoundRect(
            color = WaitingOrange,
            topLeft = Offset(w * 0.3f - barWidth / 2, h - waitH),
            size = Size(barWidth, waitH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
          )

          // Rescued Bar
          val rescH = (rescued / maxVal) * h
          drawRoundRect(
            color = RescuedGreen,
            topLeft = Offset(w * 0.7f - barWidth / 2, h - rescH),
            size = Size(barWidth, rescH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
          )
        }

        // Values over bars
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = waiting.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WaitingOrange)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = rescued.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RescuedGreen)
          }
        }

        Text(
          text = "Status",
          fontSize = 10.sp,
          color = TextMuted,
          modifier = Modifier.align(Alignment.BottomCenter)
        )
      }
    }
  }
}

// Chart 3: Top Locations (Bar Chart)
@Composable
fun TopLocationsChart(modifier: Modifier = Modifier) {
  val locations = listOf(
    Pair("Central Area", 18),
    Pair("East Colony", 12),
    Pair("Market Road", 9),
    Pair("Station Area", 7)
  )

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("chart_top_locations")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.LocationOn,
          contentDescription = null,
          tint = RoyalBlue,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "Top Locations", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDark)
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val maxVal = 20f
        for ((loc, count) in locations) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = loc,
              fontSize = 11.sp,
              color = TextDark,
              modifier = Modifier.width(90.dp)
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFFE2E8F0))
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth(count / maxVal)
                  .height(14.dp)
                  .clip(RoundedCornerShape(7.dp))
                  .background(RoyalBlue)
              )
            }

            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = count.toString(),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = NavyDark,
              modifier = Modifier.width(22.dp)
            )
          }
        }
      }
    }
  }
}

// Chart 4: Rescuer Performance (Bar Chart)
@Composable
fun RescuerPerformanceChart(modifier: Modifier = Modifier) {
  val rescuers = listOf(
    Pair("Ravi Kumar", 15),
    Pair("Sneha Patil", 12),
    Pair("Amit Singh", 9)
  )

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("chart_rescuer_performance")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Group,
          contentDescription = null,
          tint = PurpleBar,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "Rescuer Performance", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDark)
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val maxVal = 18f
        for ((rescuer, count) in rescuers) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = rescuer,
              fontSize = 11.sp,
              color = TextDark,
              modifier = Modifier.width(90.dp)
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFFEDE9FE))
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth(count / maxVal)
                  .height(14.dp)
                  .clip(RoundedCornerShape(7.dp))
                  .background(PurpleBar)
              )
            }

            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = count.toString(),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = PurpleBar,
              modifier = Modifier.width(22.dp)
            )
          }
        }
      }
    }
  }
}

// Chart 5: Health Detection Stats (Donut Chart)
@Composable
fun HealthDetectionStatsChart(modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("chart_health_detection")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Favorite,
          contentDescription = null,
          tint = RoyalBlue,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "Health Detection Stats", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NavyDark)
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        // Donut Ring
        Box(
          modifier = Modifier.size(90.dp),
          contentAlignment = Alignment.Center
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 14.dp.toPx()
            // Potentially Unhealthy (68%)
            drawArc(
              color = WaitingOrange,
              startAngle = -90f,
              sweepAngle = 360f * 0.68f,
              useCenter = false,
              style = Stroke(width = strokeWidth)
            )
            // Uncertain (32%)
            drawArc(
              color = SkyBlue,
              startAngle = -90f + 360f * 0.68f,
              sweepAngle = 360f * 0.32f,
              useCenter = false,
              style = Stroke(width = strokeWidth)
            )
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "48", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Text(text = "Total", fontSize = 10.sp, color = TextMuted)
          }
        }

        // Legend
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(WaitingOrange))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Potentially Unhealthy ", fontSize = 11.sp, color = TextDark)
            Text(text = "68%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WaitingOrange)
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(SkyBlue))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Uncertain ", fontSize = 11.sp, color = TextDark)
            Text(text = "32%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SkyBlue)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFFEE2E2).copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = "Note: Based on visual screening, not a medical diagnosis.",
          fontSize = 10.sp,
          color = Color(0xFFB91C1C),
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
      }
    }
  }
}
