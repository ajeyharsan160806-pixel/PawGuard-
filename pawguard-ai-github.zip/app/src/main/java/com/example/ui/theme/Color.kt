package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDark = Color(0xFF0A2540)
val NavyPrimary = Color(0xFF0D3B66)
val NavyLight = Color(0xFF1E40AF)
val RoyalBlue = Color(0xFF1976D2)
val SkyBlue = Color(0xFF2563EB)
val SkyBlueLight = Color(0xFFEFF6FF)
val SkyBlueBorder = Color(0xFFBFDBFE)

val WaitingOrange = Color(0xFFEA580C)
val WaitingOrangeLight = Color(0xFFFFF7ED)
val WaitingRed = Color(0xFFDC2626)

val RescuedGreen = Color(0xFF16A34A)
val RescuedGreenLight = Color(0xFFF0FDF4)
val RescuedGreenDark = Color(0xFF15803D)

val PurpleBar = Color(0xFF7C3AED)
val PurpleBarLight = Color(0xFFDDD6FE)

val BackgroundLight = Color(0xFFF4F6FA)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
val DividerColor = Color(0xFFE5E7EB)

val AmberWarning = Color(0xFFD97706)
val BlueInfo = Color(0xFF0284C7)
