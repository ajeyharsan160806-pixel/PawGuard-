package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.User
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SkyBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.WaitingRed

@Composable
fun PawGuardHeader(
  user: User?,
  unreadNotificationsCount: Int,
  onNotificationsClick: () -> Unit,
  onProfileClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(
        brush = Brush.verticalGradient(
          colors = listOf(
            NavyDark,
            NavyPrimary
          )
        )
      )
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Brand logo + text
      Row(
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = SurfaceWhite.copy(alpha = 0.15f),
          modifier = Modifier.size(46.dp)
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_pawguard_logo),
            contentDescription = "PawGuard AI Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.padding(4.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = "PawGuard AI",
            color = SurfaceWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
          )
          Text(
            text = "Monitor • Protect • Rescue",
            color = SurfaceWhite.copy(alpha = 0.85f),
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal
          )
        }
      }

      // Actions: Bell with badge & User profile
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        IconButton(
          onClick = onNotificationsClick,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(SurfaceWhite.copy(alpha = 0.15f))
            .testTag("notification_bell_button")
        ) {
          BadgedBox(
            badge = {
              if (unreadNotificationsCount > 0) {
                Badge(
                  containerColor = WaitingRed,
                  contentColor = SurfaceWhite,
                  modifier = Modifier.testTag("unread_badge")
                ) {
                  Text(
                    text = unreadNotificationsCount.toString(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          ) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = "Notifications",
              tint = SurfaceWhite,
              modifier = Modifier.size(22.dp)
            )
          }
        }

        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(SkyBlue)
            .border(2.dp, SurfaceWhite.copy(alpha = 0.8f), CircleShape)
            .clickable(onClick = onProfileClick)
            .testTag("user_profile_avatar")
        ) {
          Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "User Profile",
            tint = SurfaceWhite,
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }
  }
}
