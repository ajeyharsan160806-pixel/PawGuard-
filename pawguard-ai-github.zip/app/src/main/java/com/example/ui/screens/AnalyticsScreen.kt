package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AnalyticsSummary
import com.example.ui.components.DetectionTrendChart
import com.example.ui.components.HealthDetectionStatsChart
import com.example.ui.components.RescueStatisticsChart
import com.example.ui.components.RescuerPerformanceChart
import com.example.ui.components.SummaryCardsGrid
import com.example.ui.components.TopLocationsChart
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted

@Composable
fun AnalyticsScreen(
  summary: AnalyticsSummary,
  modifier: Modifier = Modifier
) {
  var selectedPeriod by remember { mutableStateOf("Last 30 Days") }
  var menuExpanded by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundLight)
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("analytics_dashboard_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Title Header & Time Period Dropdown
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.ShowChart,
          contentDescription = null,
          tint = RoyalBlue,
          modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "PawGuard AI Analytics",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )
          Text(
            text = "Real-time insights on stray dog health and rescue efforts",
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }

      // Period Filter Dropdown
      Box {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = SurfaceWhite,
          shadowElevation = 1.dp,
          modifier = Modifier.clickable { menuExpanded = true }
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CalendarToday,
              contentDescription = null,
              tint = NavyDark,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = selectedPeriod,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = NavyDark
            )
            Icon(
              imageVector = Icons.Default.KeyboardArrowDown,
              contentDescription = null,
              tint = NavyDark,
              modifier = Modifier.size(14.dp)
            )
          }
        }

        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false }
        ) {
          listOf("Last 7 Days", "Last 30 Days", "Last 90 Days", "All Time").forEach { option ->
            DropdownMenuItem(
              text = { Text(option, fontSize = 12.sp) },
              onClick = {
                selectedPeriod = option
                menuExpanded = false
              }
            )
          }
        }
      }
    }

    // 4 Summary Cards (Total Detected, Waiting, Rescued, Rescue Rate ring)
    SummaryCardsGrid(summary = summary)

    // Chart 1: Detection Trend (Line Chart)
    DetectionTrendChart()

    // Chart 2: Rescue Statistics (Bar Chart)
    RescueStatisticsChart(
      waiting = summary.waitingForRescue,
      rescued = summary.totalRescued
    )

    // Chart 3: Top Locations (Horizontal Bar Chart)
    TopLocationsChart()

    // Chart 4: Rescuer Performance (Bar Chart)
    RescuerPerformanceChart()

    // Chart 5: Health Detection Stats (Donut Chart)
    HealthDetectionStatsChart()

    Spacer(modifier = Modifier.height(16.dp))
  }
}
