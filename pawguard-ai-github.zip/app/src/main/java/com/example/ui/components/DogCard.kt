package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DogDetection
import com.example.data.HealthStatus
import com.example.data.RescueStatus
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RescuedGreenLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingOrange
import com.example.ui.theme.WaitingOrangeLight
import com.example.ui.theme.WaitingRed

@Composable
fun DogCard(
  dog: DogDetection,
  onRescueClick: (DogDetection) -> Unit,
  onCardClick: (DogDetection) -> Unit,
  modifier: Modifier = Modifier
) {
  val isWaiting = dog.rescueStatus == RescueStatus.WAITING

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .clickable { onCardClick(dog) }
      .testTag("dog_card_${dog.dogId}")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Left Column: Dog Image with Floating Status Badge
        Box(
          modifier = Modifier
            .size(width = 115.dp, height = 135.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFE2E8F0))
        ) {
          if (dog.imageRes != null) {
            Image(
              painter = painterResource(id = dog.imageRes),
              contentDescription = "Dog ${dog.dogId}",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else if (!dog.imageUrl.isNullOrBlank()) {
            AsyncImage(
              model = dog.imageUrl,
              contentDescription = "Dog ${dog.dogId}",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          } else {
            Image(
              painter = painterResource(id = R.drawable.dog_sample_1),
              contentDescription = "Dog default photo",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
          }

          // Status Badge overlay
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isWaiting) WaitingRed else RescuedGreen,
            modifier = Modifier
              .padding(4.dp)
              .align(Alignment.TopStart)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Icon(
                imageVector = if (isWaiting) Icons.Default.Warning else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = SurfaceWhite,
                modifier = Modifier.size(10.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = if (isWaiting) "WAITING" else "RESCUED",
                color = SurfaceWhite,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
              )
            }
          }
        }

        // Center / Info Column
        Column(
          modifier = Modifier.weight(1f)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Dog ID: ${dog.dogId}",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark
              )
              Text(
                text = "Detection ID: ${dog.detectionId}",
                fontSize = 11.sp,
                color = TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            // Map thumbnail preview
            Box(
              modifier = Modifier
                .size(width = 64.dp, height = 44.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFE2E8F0))
                .border(1.dp, BorderLight, RoundedCornerShape(8.dp))
                .clickable { onCardClick(dog) },
              contentAlignment = Alignment.Center
            ) {
              // Simulated map background pattern
              Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceEvenly
              ) {
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFCBD5E1)))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFCBD5E1)))
              }
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Map Location",
                tint = if (isWaiting) WaitingRed else RescuedGreen,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Rescued info if rescued
          if (!isWaiting && !dog.rescuedBy.isNullOrBlank()) {
            Text(
              text = "Rescued by: ${dog.rescuedBy}",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = RescuedGreen
            )
            Spacer(modifier = Modifier.height(2.dp))
          }

          // Location
          Row(
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = NavyDark,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = dog.locationName,
              fontSize = 11.sp,
              color = TextDark,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          // Captured Date & Time
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CalendarToday,
              contentDescription = null,
              tint = TextMuted,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = dog.capturedAt,
              fontSize = 11.sp,
              color = TextMuted
            )
          }

          // Health & Confidence
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = if (dog.healthStatus == HealthStatus.POTENTIALLY_UNHEALTHY) WaitingOrange else RoyalBlue,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Health: ",
              fontSize = 11.sp,
              color = TextDark
            )
            Text(
              text = dog.healthStatus.label,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (dog.healthStatus == HealthStatus.POTENTIALLY_UNHEALTHY) WaitingOrange else RoyalBlue
            )
            Text(
              text = " (${(dog.healthConfidence.coerceIn(0f, 1f) * 100).toInt()}%)",
              fontSize = 11.sp,
              color = TextMuted
            )
          }

          // If rescued, show green pill
          if (!isWaiting && !dog.rescuedAt.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = RescuedGreenLight
            ) {
              Text(
                text = "✓ Rescued on ${dog.rescuedAt}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = RescuedGreen,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Bottom Action Button
      if (isWaiting) {
        Button(
          onClick = { onRescueClick(dog) },
          colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .testTag("mark_as_rescued_button_${dog.dogId}")
        ) {
          Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            tint = SurfaceWhite,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Mark as Rescued",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = SurfaceWhite
          )
        }
      } else {
        OutlinedButton(
          onClick = { onCardClick(dog) },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = RoyalBlue),
          modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .testTag("view_details_button_${dog.dogId}")
        ) {
          Text(
            text = "View Rescue Details",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }
  }
}
