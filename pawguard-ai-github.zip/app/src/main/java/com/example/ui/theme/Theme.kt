package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val PawGuardColorScheme = lightColorScheme(
  primary = RoyalBlue,
  onPrimary = SurfaceWhite,
  primaryContainer = SkyBlueLight,
  onPrimaryContainer = NavyDark,
  secondary = NavyPrimary,
  onSecondary = SurfaceWhite,
  secondaryContainer = SkyBlueLight,
  onSecondaryContainer = NavyPrimary,
  tertiary = RescuedGreen,
  onTertiary = SurfaceWhite,
  background = BackgroundLight,
  onBackground = TextDark,
  surface = SurfaceWhite,
  onSurface = TextDark,
  surfaceVariant = BackgroundLight,
  onSurfaceVariant = TextMuted,
  outline = BorderLight,
  outlineVariant = DividerColor,
  error = WaitingRed,
  onError = SurfaceWhite
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as Activity).window
      window.statusBarColor = NavyDark.toArgb()
      WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
    }
  }

  MaterialTheme(
    colorScheme = PawGuardColorScheme,
    typography = Typography,
    content = content
  )
}
