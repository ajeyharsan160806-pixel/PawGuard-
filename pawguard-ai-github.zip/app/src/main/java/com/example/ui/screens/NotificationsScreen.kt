package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppNotification
import com.example.data.NotificationType
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WaitingOrange
import com.example.ui.theme.WaitingRed

@Composable
fun NotificationsScreen(
  notifications: List<AppNotification>,
  onMarkAllRead: () -> Unit,
  onClearAll: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundLight)
      .testTag("notifications_screen")
  ) {
    // Header
    Surface(
      color = SurfaceWhite,
      shadowElevation = 1.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Real-Time Notifications",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyDark
          )
          Text(
            text = "Alerts for new unhealthy detections and rescue updates",
            fontSize = 12.sp,
            color = TextMuted
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(
            onClick = onMarkAllRead,
            modifier = Modifier.testTag("mark_all_read_btn")
          ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = "Mark all read", tint = RoyalBlue)
          }
          IconButton(
            onClick = onClearAll,
            modifier = Modifier.testTag("clear_all_notifs_btn")
          ) {
            Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear all", tint = TextMuted)
          }
        }
      }
    }

    if (notifications.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Notifications,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(54.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "No Notifications",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = "New IoT dog detections and rescue events will appear here in real-time.",
            fontSize = 12.sp,
            color = TextMuted,
            modifier = Modifier.padding(top = 4.dp)
          )
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(notifications, key = { it.notificationId }) { notif ->
          NotificationCard(notification = notif)
        }
      }
    }
  }
}

@Composable
private fun NotificationCard(notification: AppNotification) {
  val iconColor = when (notification.type) {
    NotificationType.NEW_DETECTION -> WaitingOrange
    NotificationType.RESCUE_COMPLETED -> RescuedGreen
    NotificationType.DEVICE_ALERT -> RoyalBlue
    NotificationType.SYSTEM -> NavyDark
  }

  val icon = when (notification.type) {
    NotificationType.NEW_DETECTION -> Icons.Default.Warning
    NotificationType.RESCUE_COMPLETED -> Icons.Default.Favorite
    NotificationType.DEVICE_ALERT -> Icons.Default.Hardware
    NotificationType.SYSTEM -> Icons.Default.NotificationsActive
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (notification.isRead) SurfaceWhite else Color(0xFFEFF6FF)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.Top
    ) {
      Surface(
        shape = CircleShape,
        color = iconColor.copy(alpha = 0.15f),
        modifier = Modifier.size(38.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        }
      }

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = notification.title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = notification.timestamp,
            fontSize = 11.sp,
            color = TextMuted
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = notification.message,
          fontSize = 12.sp,
          color = TextDark,
          lineHeight = 16.sp
        )

        if (!notification.dogId.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = Color(0xFFE2E8F0)
          ) {
            Text(
              text = "Dog ID: ${notification.dogId}",
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = NavyDark,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }
    }
  }
}
