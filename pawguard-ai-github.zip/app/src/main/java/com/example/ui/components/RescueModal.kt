package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.DogDetection
import com.example.data.User
import com.example.ui.theme.BorderLight
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RescuedGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RescueModal(
  dog: DogDetection,
  currentUser: User?,
  onDismiss: () -> Unit,
  onConfirmRescue: (dogId: String, rescuerName: String, org: String, date: String, time: String, notes: String) -> Unit
) {
  val defaultDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
  val defaultTime = remember { SimpleDateFormat("hh:mm a", Locale.US).format(Date()) }

  var rescuerName by remember { mutableStateOf(currentUser?.displayName ?: "Sarah Jenkins") }
  var organization by remember { mutableStateOf(currentUser?.organization ?: "PawGuard Care Network") }
  var rescueDate by remember { mutableStateOf(defaultDate) }
  var rescueTime by remember { mutableStateOf(defaultTime) }
  var rescueNotes by remember { mutableStateOf("") }
  var isSubmitting by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp)
        .testTag("rescue_modal_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Modal Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SkyBlueLight),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = RoyalBlue,
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Record Rescue Activity",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
              )
              Text(
                text = "Dog ID: ${dog.dogId} • ${dog.locationName}",
                fontSize = 12.sp,
                color = TextMuted
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("close_rescue_modal")
          ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Info notice
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFFF1F5F9),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Marking this dog as rescued will update cloud analytics, notify other rescue units, and archive the active alert.",
            fontSize = 11.sp,
            color = TextDark,
            modifier = Modifier.padding(10.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Field 1: Rescuer Name
        Text(
          text = "Rescuer Name *",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = rescuerName,
          onValueChange = { rescuerName = it },
          placeholder = { Text("Enter rescuer name") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = RoyalBlue)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_rescuer_name"),
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = BorderLight,
            focusedBorderColor = RoyalBlue
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Field 2: Rescue Organization
        Text(
          text = "Rescue Organization *",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = organization,
          onValueChange = { organization = it },
          placeholder = { Text("e.g. Blue Cross, PAWS") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Business, contentDescription = null, tint = RoyalBlue)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_rescue_org"),
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = BorderLight,
            focusedBorderColor = RoyalBlue
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Field 3 & 4: Date & Time
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Rescue Date",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = rescueDate,
              onValueChange = { rescueDate = it },
              leadingIcon = {
                Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = BorderLight,
                focusedBorderColor = RoyalBlue
              )
            )
          }

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Rescue Time",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TextDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = rescueTime,
              onValueChange = { rescueTime = it },
              leadingIcon = {
                Icon(imageVector = Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = BorderLight,
                focusedBorderColor = RoyalBlue
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Field 5: Optional Rescue Remarks
        Text(
          text = "Rescue Remarks / Medical Action",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
          value = rescueNotes,
          onValueChange = { rescueNotes = it },
          placeholder = { Text("e.g. Wound cleaned, treated at shelter clinic") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Notes, contentDescription = null, tint = TextMuted)
          },
          maxLines = 3,
          minLines = 2,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_rescue_notes"),
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = BorderLight,
            focusedBorderColor = RoyalBlue
          )
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1f)
              .height(46.dp)
              .testTag("cancel_rescue_button")
          ) {
            Text("Cancel", color = TextMuted)
          }

          Button(
            onClick = {
              if (rescuerName.isNotBlank() && !isSubmitting) {
                isSubmitting = true
                onConfirmRescue(dog.detectionId, rescuerName, organization, rescueDate, rescueTime, rescueNotes)
              }
            },
            enabled = rescuerName.isNotBlank() && !isSubmitting,
            colors = ButtonDefaults.buttonColors(containerColor = RescuedGreen),
            modifier = Modifier
              .weight(1.3f)
              .height(46.dp)
              .testTag("confirm_rescue_button")
          ) {
            Icon(
              imageVector = Icons.Default.Favorite,
              contentDescription = null,
              tint = SurfaceWhite,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isSubmitting) "Saving..." else "Confirm Rescue",
              fontWeight = FontWeight.Bold,
              color = SurfaceWhite
            )
          }
        }
      }
    }
  }
}
