import React, { useState } from "react";
import { DogDetection } from "../types/dog";
import { DogCard } from "./DogCard";
import { RescueModal } from "./RescueModal";
import { CreateDetectionModal } from "./CreateDetectionModal";

interface DogMonitoringProps {
  waitingDogs: DogDetection[];
  rescuedDogs: DogDetection[];
  loading: boolean;
  error: string | null;
  onConfirmRescue: (docId: string, rescuerName: string) => Promise<void>;
}

export const DogMonitoring: React.FC<DogMonitoringProps> = ({
  waitingDogs,
  rescuedDogs,
  loading,
  error,
  onConfirmRescue
}) => {
  const [activeTab, setActiveTab] = useState<"all" | "waiting" | "rescued">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDogForRescue, setSelectedDogForRescue] = useState<DogDetection | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const filterDogs = (list: DogDetection[]) => {
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter(
      (d) =>
        d.dogId.toLowerCase().includes(q) ||
        d.id.toLowerCase().includes(q) ||
        d.healthStatus.toLowerCase().includes(q) ||
        (d.rescuedBy && d.rescuedBy.toLowerCase().includes(q))
    );
  };

  const filteredWaiting = filterDogs(waitingDogs);
  const filteredRescued = filterDogs(rescuedDogs);

  return (
    <div className="space-y-6">
      {/* Search and Section Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Unhealthy Dogs Monitoring</h2>
            <p className="text-xs text-slate-500">
              Live records synchronized from Cloud Firestore collection <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-700 font-mono">dog_detections</code>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Quick Tab Filter: All, Waiting for Rescue, Rescued */}
            <div className="inline-flex rounded-lg bg-slate-100 p-1 border border-slate-200">
              <button
                onClick={() => setActiveTab("all")}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  activeTab === "all" ? "bg-white text-blue-900 shadow-sm" : "text-slate-600 hover:text-slate-900"
                }`}
              >
                All ({waitingDogs.length + rescuedDogs.length})
              </button>
              <button
                onClick={() => setActiveTab("waiting")}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  activeTab === "waiting" ? "bg-amber-600 text-white shadow-sm" : "text-slate-600 hover:text-slate-900"
                }`}
              >
                Waiting for Rescue ({waitingDogs.length})
              </button>
              <button
                onClick={() => setActiveTab("rescued")}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  activeTab === "rescued" ? "bg-green-600 text-white shadow-sm" : "text-slate-600 hover:text-slate-900"
                }`}
              >
                Rescued ({rescuedDogs.length})
              </button>
            </div>

            {/* Record Detection Button */}
            <button
              onClick={() => setShowCreateModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
              </svg>
              <span>+ Record Detection</span>
            </button>
          </div>
        </div>

        {/* Search input */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Dog ID, document ID, health status, or rescuer..."
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-slate-50/50"
          />
          <svg className="w-5 h-5 text-slate-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent mb-3"></div>
          <p className="text-sm font-semibold text-slate-700">Connecting to Cloud Firestore...</p>
          <p className="text-xs text-slate-400 mt-1">Listening to real-time updates via onSnapshot</p>
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-red-800">
          <div className="flex items-start gap-3">
            <svg className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div className="space-y-2">
              <h4 className="font-bold text-sm">Firestore Connection Notice</h4>
              <p className="text-xs text-red-700">{error}</p>
              {error.includes("permission") && (
                <div className="p-3 bg-white/80 rounded-lg text-xs font-mono text-slate-800 border border-red-200">
                  <p className="font-bold text-slate-900 mb-1">To allow read/write in Firebase Console:</p>
                  <p className="text-slate-600">Firestore Database ➔ Rules ➔ Change to:</p>
                  <code className="text-blue-700 block mt-1 font-bold">
                    allow read, write: if true;
                  </code>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && waitingDogs.length === 0 && rescuedDogs.length === 0 && (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <svg className="w-16 h-16 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          <h3 className="text-base font-bold text-slate-800">No Dog Detections In Firestore</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            Documents added to the <code className="font-mono text-blue-600 font-bold">dog_detections</code> collection in project <code className="font-mono">pawguard-54ad8</code> will appear here automatically via real-time sync.
          </p>
        </div>
      )}

      {/* Waiting for Rescue Section */}
      {!loading && (activeTab === "all" || activeTab === "waiting") && filteredWaiting.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Waiting for Rescue ({filteredWaiting.length})
            </h3>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {filteredWaiting.map((dog) => (
              <DogCard
                key={dog.id}
                dog={dog}
                onOpenRescueModal={(d) => setSelectedDogForRescue(d)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Rescued Section */}
      {!loading && (activeTab === "all" || activeTab === "rescued") && filteredRescued.length > 0 && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-green-500"></span>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Rescued Dogs ({filteredRescued.length})
            </h3>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {filteredRescued.map((dog) => (
              <DogCard
                key={dog.id}
                dog={dog}
                onOpenRescueModal={(d) => setSelectedDogForRescue(d)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Rescue Modal */}
      {selectedDogForRescue && (
        <RescueModal
          dog={selectedDogForRescue}
          onClose={() => setSelectedDogForRescue(null)}
          onConfirmRescue={onConfirmRescue}
        />
      )}

      {/* Record Detection Modal */}
      {showCreateModal && (
        <CreateDetectionModal
          onClose={() => setShowCreateModal(false)}
        />
      )}
    </div>
  );
};
