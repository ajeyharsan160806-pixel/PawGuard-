import React from "react";
import { DogDetection } from "../types/dog";
import { formatConfidencePercent } from "../utils/confidenceUtils";

interface DogCardProps {
  dog: DogDetection;
  onOpenRescueModal: (dog: DogDetection) => void;
}

export const DogCard: React.FC<DogCardProps> = ({ dog, onOpenRescueModal }) => {
  const isRescued = (dog.rescueStatus || "").toLowerCase().includes("rescue");

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col md:flex-row transition-all hover:shadow-md">
      {/* Dog Image Section */}
      <div className="relative w-full md:w-48 h-48 bg-slate-100 flex-shrink-0 flex items-center justify-center overflow-hidden">
        {dog.imageUrl ? (
          <img
            src={dog.imageUrl}
            alt={`Dog ${dog.dogId}`}
            className="w-full h-full object-cover"
            onError={(e) => {
              // Image fallback
              (e.target as HTMLImageElement).src =
                "https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=500&q=80";
            }}
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-slate-400 p-4">
            <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <span className="text-xs font-medium">No Image Uploaded</span>
          </div>
        )}

        {/* Status Badge */}
        <div className="absolute top-2 left-2">
          {isRescued ? (
            <span className="inline-flex items-center gap-1 bg-green-600 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-sm">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
              </svg>
              RESCUED
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 bg-amber-600 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-sm">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              WAITING FOR RESCUE
            </span>
          )}
        </div>
      </div>

      {/* Info Section */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Dog ID: {dog.dogId}</h3>
              <p className="text-xs text-slate-500 font-mono">Doc ID: {dog.id}</p>
            </div>
            {dog.confidence !== null && dog.confidence !== undefined && (
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                AI Confidence: {formatConfidencePercent(dog.confidence)}
              </span>
            )}
          </div>

          <div className="space-y-1.5 text-xs text-slate-600">
            {/* Health Status */}
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700">Health Status:</span>
              <span className={`font-bold ${isRescued ? "text-green-700" : "text-amber-700"}`}>
                {dog.healthStatus}
              </span>
            </div>

            {/* GPS Coordinates */}
            <div className="flex items-center gap-1.5">
              <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span>
                Lat: {dog.latitude?.toFixed ? dog.latitude.toFixed(5) : dog.latitude}, Lng: {dog.longitude?.toFixed ? dog.longitude.toFixed(5) : dog.longitude}
              </span>
            </div>

            {/* Captured Date & Time */}
            <div className="flex items-center gap-1.5">
              <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span>Captured: {dog.capturedAt}</span>
            </div>

            {/* Rescued By */}
            {isRescued && dog.rescuedBy && (
              <div className="mt-2 p-2 rounded bg-green-50 border border-green-200 text-green-800 flex items-center gap-2">
                <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Rescued by: <strong>{dog.rescuedBy}</strong></span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
          {!isRescued ? (
            <button
              onClick={() => onOpenRescueModal(dog)}
              className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
              Mark as Rescued
            </button>
          ) : (
            <span className="text-xs text-green-700 font-semibold flex items-center gap-1">
              ✓ Rescue Activity Recorded in Firestore
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
