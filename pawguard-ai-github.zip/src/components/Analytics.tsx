import React from "react";
import { DogStatistics } from "../hooks/useDogDetections";

interface AnalyticsProps {
  stats: DogStatistics;
  loading: boolean;
}

export const Analytics: React.FC<AnalyticsProps> = ({ stats, loading }) => {
  const locationEntries = Object.entries(stats.locations).sort((a, b) => b[1] - a[1]);
  const rescuerEntries = Object.entries(stats.rescuers).sort((a, b) => b[1] - a[1]);

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <h2 className="text-xl font-bold text-slate-900">PawGuard AI Analytics</h2>
          <p className="text-xs text-slate-500">
            Real-time statistics computed strictly from actual Cloud Firestore records
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
          <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
          Live Firestore Data
        </span>
      </div>

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Card 1: Total Unhealthy */}
        <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-sm flex flex-col justify-between h-36">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <div className="text-3xl font-extrabold">{loading ? "..." : stats.total}</div>
            <div className="text-xs text-slate-300 font-medium mt-1 leading-tight">
              Total Unhealthy<br />Dogs Detected
            </div>
          </div>
        </div>

        {/* Card 2: Waiting for Rescue */}
        <div className="bg-amber-600 text-white rounded-2xl p-5 shadow-sm flex flex-col justify-between h-36">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <div className="text-3xl font-extrabold">{loading ? "..." : stats.waiting}</div>
            <div className="text-xs text-amber-100 font-medium mt-1 leading-tight">
              Waiting for<br />Rescue
            </div>
          </div>
        </div>

        {/* Card 3: Total Rescued */}
        <div className="bg-green-600 text-white rounded-2xl p-5 shadow-sm flex flex-col justify-between h-36">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <div className="text-3xl font-extrabold">{loading ? "..." : stats.rescued}</div>
            <div className="text-xs text-green-100 font-medium mt-1 leading-tight">
              Total<br />Rescued
            </div>
          </div>
        </div>

        {/* Card 4: Rescue Rate */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col items-center justify-center h-36 text-center">
          <div className="relative w-16 h-16 flex items-center justify-center mb-1">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-100"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-green-600 transition-all duration-1000"
                strokeDasharray={`${stats.rescueRate}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <span className="absolute text-sm font-bold text-slate-800">
              {loading ? "..." : `${stats.rescueRate}%`}
            </span>
          </div>
          <span className="text-xs font-bold text-slate-700">Rescue Rate</span>
        </div>
      </div>

      {/* Breakdown Grids */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Location Breakdown */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <h3 className="font-bold text-slate-900 text-sm">Detections by Location</h3>
          </div>

          {locationEntries.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">No location records available in database yet.</p>
          ) : (
            <div className="space-y-2">
              {locationEntries.map(([loc, count]) => {
                const pct = stats.total > 0 ? (count / stats.total) * 100 : 0;
                return (
                  <div key={loc} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-700 truncate max-w-[200px]">{loc}</span>
                      <span className="font-bold text-slate-900">{count} dogs</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-blue-600 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Rescuer Performance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <h3 className="font-bold text-slate-900 text-sm">Rescuer Performance</h3>
          </div>

          {rescuerEntries.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">No rescues have been marked in Firestore yet.</p>
          ) : (
            <div className="space-y-2">
              {rescuerEntries.map(([rescuer, count]) => {
                const pct = stats.rescued > 0 ? (count / stats.rescued) * 100 : 0;
                return (
                  <div key={rescuer} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-700">{rescuer}</span>
                      <span className="font-bold text-purple-700">{count} rescued</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-600 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
