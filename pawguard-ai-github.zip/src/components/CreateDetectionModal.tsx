import React, { useState } from "react";
import { createDogDetection } from "../services/dogService";
import { formatConfidencePercent, isValidConfidenceInput } from "../utils/confidenceUtils";

interface CreateDetectionModalProps {
  onClose: () => void;
  onSuccess?: () => void;
}

export const CreateDetectionModal: React.FC<CreateDetectionModalProps> = ({ onClose, onSuccess }) => {
  const [dogId, setDogId] = useState(`DG-${Math.floor(100 + Math.random() * 900)}`);
  const [healthStatus, setHealthStatus] = useState("Potentially Unhealthy");
  const [latitude, setLatitude] = useState("13.0827");
  const [longitude, setLongitude] = useState("80.2707");
  const [confidenceInput, setConfidenceInput] = useState("0.92");
  const [confidence, setConfidence] = useState<number>(0.92);
  const [imageUrl, setImageUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Exact step 2 conversion requested by user:
  const handleConfidenceChange = (value: string) => {
    setConfidenceInput(value);
    const num = Number(value);

    if (!Number.isFinite(num)) {
      setError("Please enter a valid numeric confidence.");
      return;
    }

    if (num < 0 || num > 1) {
      setError("Confidence must be a decimal between 0 and 1 (e.g. 0.92).");
      return;
    }

    setError(null);
    setConfidence(num);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const numericConfidence = Number(confidenceInput);
    if (!Number.isFinite(numericConfidence) || numericConfidence < 0 || numericConfidence > 1) {
      setError("Confidence must be a decimal between 0.00 and 1.00 (e.g. 0.92).");
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      await createDogDetection({
        dogId: dogId.trim(),
        healthStatus,
        latitude: Number(latitude) || 13.0827,
        longitude: Number(longitude) || 80.2707,
        capturedAt: new Date().toLocaleString(),
        rescueStatus: "Waiting for rescue",
        imageUrl: imageUrl.trim() || null,
        confidence: Number(numericConfidence) // Stored as Firestore double
      });

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || "Failed to create document in Firestore.");
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2 text-slate-900 font-bold text-lg">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
            </svg>
            <span>Record New Dog Detection</span>
          </div>
          <button onClick={onClose} disabled={submitting} className="text-slate-400 hover:text-slate-600 p-1 rounded-lg">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Dog ID *</label>
              <input
                type="text"
                value={dogId}
                onChange={(e) => setDogId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Health Status *</label>
              <select
                value={healthStatus}
                onChange={(e) => setHealthStatus(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 bg-white"
              >
                <option value="Potentially Unhealthy">Potentially Unhealthy</option>
                <option value="Uncertain">Uncertain</option>
                <option value="Healthy">Healthy</option>
              </select>
            </div>
          </div>

          {/* Confidence Field */}
          <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-100">
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="confidence" className="block text-xs font-bold text-blue-900 uppercase tracking-wider">
                AI Confidence (Decimal 0.0 - 1.0) *
              </label>
              <span className="text-xs font-extrabold text-blue-700 bg-white px-2 py-0.5 rounded shadow-xs">
                Display: {formatConfidencePercent(confidence)}
              </span>
            </div>
            <input
              id="confidence"
              type="number"
              step="0.01"
              min="0"
              max="1"
              value={confidenceInput}
              onChange={(e) => handleConfidenceChange(e.target.value)}
              placeholder="e.g., 0.92"
              className="w-full px-3 py-2 bg-white border border-blue-200 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <div className="mt-2 flex items-center justify-between text-[11px] text-blue-600 font-medium">
              <span>Test presets:</span>
              <div className="flex gap-1">
                {[0.92, 0.85, 0.50, 1.00].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => handleConfidenceChange(val.toString())}
                    className="px-2 py-0.5 bg-white hover:bg-blue-100 border border-blue-200 rounded text-blue-800 font-bold transition-colors"
                  >
                    {val} ({Math.round(val * 100)}%)
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Latitude</label>
              <input
                type="text"
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Longitude</label>
              <input
                type="text"
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Image URL (Optional)</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://...jpg"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
            />
          </div>

          <div className="flex gap-2 justify-end pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm flex items-center gap-2"
            >
              {submitting ? "Saving to Firestore..." : "Save Detection"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
