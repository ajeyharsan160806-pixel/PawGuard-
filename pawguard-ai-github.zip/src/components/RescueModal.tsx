import React, { useState } from "react";
import { DogDetection } from "../types/dog";

interface RescueModalProps {
  dog: DogDetection;
  onClose: () => void;
  onConfirmRescue: (docId: string, rescuerName: string) => Promise<void>;
}

export const RescueModal: React.FC<RescueModalProps> = ({
  dog,
  onClose,
  onConfirmRescue
}) => {
  const [rescuerName, setRescuerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rescuerName.trim()) {
      setError("Please enter the rescuer's name.");
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      await onConfirmRescue(dog.id, rescuerName.trim());
      onClose();
    } catch (err: any) {
      setError(err.message || "Failed to update record in Firestore.");
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2 text-blue-900 font-bold text-lg">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <span>Record Rescue Activity</span>
          </div>
          <button
            onClick={onClose}
            disabled={submitting}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-4 bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs text-slate-600 space-y-1">
          <p><strong className="text-slate-900">Target Dog ID:</strong> {dog.dogId}</p>
          <p><strong className="text-slate-900">Firestore Doc ID:</strong> <span className="font-mono">{dog.id}</span></p>
          <p><strong className="text-slate-900">Health:</strong> {dog.healthStatus}</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="rescuerName" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Rescuer's Full Name *
            </label>
            <input
              id="rescuerName"
              type="text"
              autoFocus
              value={rescuerName}
              onChange={(e) => setRescuerName(e.target.value)}
              placeholder="e.g., Sarah Jenkins, Animal Care Team"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={submitting}
            />
            <p className="mt-1 text-xs text-slate-500">
              This will update <code className="bg-slate-100 px-1 rounded">rescueStatus</code> to <strong>Rescued</strong> and <code className="bg-slate-100 px-1 rounded">rescuedBy</code> in Firestore.
            </p>
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !rescuerName.trim()}
              className="px-5 py-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2"
            >
              {submitting ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  Updating Firestore...
                </>
              ) : (
                "Confirm Rescue"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
