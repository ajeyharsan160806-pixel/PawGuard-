import { useState, useEffect, useMemo, useCallback } from "react";
import { DogDetection } from "../types/dog";
import { subscribeToDogs, markDogAsRescued } from "../services/dogService";

export interface DogStatistics {
  total: number;
  waiting: number;
  rescued: number;
  rescueRate: number;
  locations: { [location: string]: number };
  rescuers: { [rescuer: string]: number };
}

export function useDogDetections() {
  const [dogs, setDogs] = useState<DogDetection[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);

    const unsubscribe = subscribeToDogs(
      (data: DogDetection[]) => {
        setDogs(data);
        setLoading(false);
        setError(null);
      },
      (err: Error) => {
        let msg = err.message || "Failed to connect to Firestore.";
        if ((err as any).code === "permission-denied") {
          msg = "Access Denied: Missing or insufficient permissions. Please check your Firestore Security Rules in Firebase Console.";
        }
        setError(msg);
        setLoading(false);
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const isRescued = (status: string) => {
    const s = (status || "").toLowerCase();
    return s.includes("rescue");
  };

  const waitingDogs = useMemo(() => {
    return dogs.filter((d) => !isRescued(d.rescueStatus));
  }, [dogs]);

  const rescuedDogs = useMemo(() => {
    return dogs.filter((d) => isRescued(d.rescueStatus));
  }, [dogs]);

  const stats: DogStatistics = useMemo(() => {
    const total = dogs.length;
    const waiting = waitingDogs.length;
    const rescued = rescuedDogs.length;
    const rescueRate = total > 0 ? Math.round((rescued / total) * 100) : 0;

    const locations: { [location: string]: number } = {};
    const rescuers: { [rescuer: string]: number } = {};

    dogs.forEach((d) => {
      const loc = d.locationName || `${d.latitude.toFixed(2)}, ${d.longitude.toFixed(2)}`;
      locations[loc] = (locations[loc] || 0) + 1;

      if (d.rescuedBy && d.rescuedBy.trim()) {
        const r = d.rescuedBy.trim();
        rescuers[r] = (rescuers[r] || 0) + 1;
      }
    });

    return {
      total,
      waiting,
      rescued,
      rescueRate,
      locations,
      rescuers
    };
  }, [dogs, waitingDogs, rescuedDogs]);

  const rescueDog = useCallback(async (docId: string, rescuerName: string) => {
    try {
      await markDogAsRescued(docId, rescuerName);
    } catch (err: any) {
      throw new Error(err.message || "Failed to update rescue status.");
    }
  }, []);

  return {
    dogs,
    waitingDogs,
    rescuedDogs,
    loading,
    error,
    stats,
    rescueDog
  };
}
