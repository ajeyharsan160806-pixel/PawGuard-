/**
 * Confidence validation and conversion utilities for PawGuard AI.
 * Ensures decimal values (0.0 to 1.0) are preserved with precision,
 * never truncated with parseInt(), and correctly formatted as percentages.
 */

/**
 * Parses any incoming confidence value (string, number, or Firestore field)
 * into a valid float between 0.0 and 1.0.
 *
 * Test cases:
 * - 0.92 -> 0.92
 * - "0.92" -> 0.92
 * - 0.85 -> 0.85
 * - 0.50 -> 0.50
 * - 1.00 -> 1.00
 * - 92 (legacy percent) -> 0.92
 */
export const parseConfidence = (value: unknown): number => {
  if (value === null || value === undefined || value === "") {
    return 0;
  }

  // Use Number() to convert, preserving all decimal precision
  const num = Number(value);

  // Guard against NaN or non-finite numbers
  if (!Number.isFinite(num)) {
    return 0;
  }

  // If a legacy whole number percentage was passed (e.g. 92 instead of 0.92)
  if (num > 1 && num <= 100) {
    return Number((num / 100).toFixed(4));
  }

  // Clamp strictly between 0 and 1
  return Math.max(0, Math.min(1, num));
};

/**
 * Formats a decimal confidence value (0.0 - 1.0) into a percentage string.
 *
 * Test cases:
 * - 0.92 -> "92%"
 * - 0.85 -> "85%"
 * - 0.50 -> "50%"
 * - 1.00 -> "100%"
 */
export const formatConfidencePercent = (confidence: unknown): string => {
  if (confidence === null || confidence === undefined || confidence === "") {
    return "N/A";
  }

  const num = Number(confidence);
  if (!Number.isFinite(num)) {
    return "N/A";
  }

  // Normalize: if it's already between 0 and 1, multiply by 100
  const normalizedPercent = num >= 0 && num <= 1 ? num * 100 : num;

  // Never return negative values
  const safePercent = Math.max(0, Math.min(100, Math.round(normalizedPercent)));
  return `${safePercent}%`;
};

/**
 * Validates whether an input represents a valid decimal confidence between 0 and 1.
 */
export const isValidConfidenceInput = (value: string | number): boolean => {
  const num = Number(value);
  return Number.isFinite(num) && num >= 0 && num <= 1;
};
