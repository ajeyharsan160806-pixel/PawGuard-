export interface DogDetection {
  id: string; // Firestore Document ID
  dogId: string;
  healthStatus: string;
  latitude: number;
  longitude: number;
  capturedAt: string;
  rescueStatus: string; // "waiting" | "Waiting for rescue" | "Rescued" | "rescued"
  rescuedBy?: string | null;
  imageUrl?: string | null;
  confidence?: number | null;
  // Optional legacy fields for backward compatibility
  deviceId?: string;
  locationName?: string;
  storagePath?: string;
  rescueOrganization?: string | null;
  rescueNotes?: string | null;
}

export interface FirestoreRawDogData {
  dogId?: string;
  dog_id?: string;
  healthStatus?: string;
  health_status?: string;
  latitude?: number | string;
  longitude?: number | string;
  capturedAt?: string | any;
  captured_at?: string | any;
  rescueStatus?: string;
  rescue_status?: string;
  rescuedBy?: string | null;
  rescued_by?: string | null;
  imageUrl?: string | null;
  image_url?: string | null;
  confidence?: number | string | null;
  health_confidence?: number | string | null;
  deviceId?: string;
  device_id?: string;
  locationName?: string;
  location_name?: string;
  rescueOrganization?: string | null;
  rescue_organization?: string | null;
  rescueNotes?: string | null;
  rescue_notes?: string | null;
  [key: string]: any;
}
