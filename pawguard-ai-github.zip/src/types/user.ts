export type UserRole = "ADMIN" | "RESCUE_USER";

export interface UserProfile {
  user_id: string;
  username: string;
  email?: string;
  displayName?: string;
  role: UserRole;
  organization?: string;
  created_at: string;
}
