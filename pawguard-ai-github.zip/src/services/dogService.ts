import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  Unsubscribe
} from "firebase/firestore";
import { db } from "../firebase";
import { DogDetection, FirestoreRawDogData } from "../types/dog";
import { parseConfidence } from "../utils/confidenceUtils";

const COLLECTION_NAME = "dog_detections";

/**
 * Normalizes a raw Firestore document snapshot into a standardized DogDetection object.
 * Preserves decimal precision for confidence values (e.g. 0.92).
 */
export function normalizeDogDoc(id: string, data: FirestoreRawDogData): DogDetection {
  let formattedDate = "Recent";
  const rawDate = data.capturedAt || data.captured_at;
  if (rawDate) {
    if (typeof rawDate === "string") {
      formattedDate = rawDate;
    } else if (rawDate.toDate && typeof rawDate.toDate === "function") {
      formattedDate = rawDate.toDate().toLocaleString();
    } else if (rawDate.seconds) {
      formattedDate = new Date(rawDate.seconds * 1000).toLocaleString();
    }
  }

  // Parse confidence strictly using Number(), preserving decimal precision and avoiding parseInt()
  const rawConf = data.confidence !== undefined ? data.confidence : data.health_confidence;
  const parsedConf = rawConf !== undefined && rawConf !== null ? parseConfidence(rawConf) : null;

  return {
    id,
    dogId: data.dogId || data.dog_id || id,
    healthStatus: data.healthStatus || data.health_status || "Potentially Unhealthy",
    latitude: Number(data.latitude) || 0,
    longitude: Number(data.longitude) || 0,
    capturedAt: formattedDate,
    rescueStatus: data.rescueStatus || data.rescue_status || "Waiting",
    rescuedBy: data.rescuedBy || data.rescued_by || null,
    imageUrl: data.imageUrl || data.image_url || null,
    confidence: parsedConf,
    deviceId: data.deviceId || data.device_id || "Street Sensor",
    locationName: data.locationName || data.location_name || `${Number(data.latitude || 0).toFixed(4)}, ${Number(data.longitude || 0).toFixed(4)}`,
    rescueOrganization: data.rescueOrganization || data.rescue_organization || null,
    rescueNotes: data.rescueNotes || data.rescue_notes || null
  };
}

/**
 * Real-time listener for dog detection records in Cloud Firestore.
 * Automatically receives real-time updates whenever documents are added, modified, or removed.
 */
export const subscribeToDogs = (callback: (dogs: DogDetection[]) => void, onError?: (error: Error) => void): Unsubscribe => {
  return onSnapshot(
    collection(db, COLLECTION_NAME),
    (snapshot) => {
      const dogs: DogDetection[] = snapshot.docs.map((docSnap) => {
        const rawData = docSnap.data() as FirestoreRawDogData;
        return normalizeDogDoc(docSnap.id, {
          id: docSnap.id,
          ...rawData
        });
      });

      callback(dogs);
    },
    (error) => {
      console.error("Firestore error:", error);
      if (onError) onError(error);
    }
  );
};

// Backward-compatible alias
export const subscribeToDogDetections = (
  onSuccess: (dogs: DogDetection[]) => void,
  onError?: (error: Error) => void
): Unsubscribe => {
  return subscribeToDogs(onSuccess, onError);
};

/**
 * Creates a new dog detection record in Firestore.
 * Strictly converts confidence to a Firestore Number (double) between 0 and 1 without parseInt().
 */
export async function createDogDetection(detectionData: Partial<DogDetection>): Promise<void> {
  const colRef = collection(db, COLLECTION_NAME);
  const docRef = doc(colRef);
  const confNumber = parseConfidence(detectionData.confidence);

  await setDoc(docRef, {
    dogId: detectionData.dogId || `DG-${Math.floor(100 + Math.random() * 900)}`,
    healthStatus: detectionData.healthStatus || "Potentially Unhealthy",
    latitude: Number(detectionData.latitude) || 13.0827,
    longitude: Number(detectionData.longitude) || 80.2707,
    capturedAt: detectionData.capturedAt || new Date().toISOString(),
    rescueStatus: detectionData.rescueStatus || "Waiting for rescue",
    rescuedBy: detectionData.rescuedBy || null,
    imageUrl: detectionData.imageUrl || null,
    confidence: Number(confNumber) // Stored as a double, never truncated with parseInt()
  });
}

/**
 * Updates a dog record in Firestore: sets rescueStatus to "Rescued" and rescuedBy to the rescuer's name.
 */
export async function markDogAsRescued(docId: string, rescuerName: string): Promise<void> {
  if (!docId) throw new Error("Document ID is required to mark as rescued.");
  if (!rescuerName.trim()) throw new Error("Rescuer name is required.");

  const docRef = doc(db, COLLECTION_NAME, docId);
  await updateDoc(docRef, {
    rescueStatus: "Rescued",
    rescuedBy: rescuerName.trim(),
    rescuedAt: new Date().toISOString()
  });
}
