import { ref, uploadBytes, uploadString, getDownloadURL } from "firebase/storage";
import { storage } from "./firebase";

/**
 * Upload a dog image to Firebase Storage and return its public download URL
 */
export async function uploadDogImage(
  dogId: string,
  detectionId: string,
  imageFile: File | Blob
): Promise<{ downloadUrl: string; storagePath: string }> {
  const timestamp = Date.now();
  const storagePath = `detections/${dogId}_${detectionId}_${timestamp}.jpg`;
  const storageRef = ref(storage, storagePath);

  await uploadBytes(storageRef, imageFile, {
    contentType: "image/jpeg"
  });

  const downloadUrl = await getDownloadURL(storageRef);
  return { downloadUrl, storagePath };
}

/**
 * Upload Base64 image received from IoT Hardware to Firebase Storage
 */
export async function uploadBase64DogImage(
  dogId: string,
  detectionId: string,
  base64Data: string
): Promise<{ downloadUrl: string; storagePath: string }> {
  const timestamp = Date.now();
  const storagePath = `detections/${dogId}_${detectionId}_${timestamp}.jpg`;
  const storageRef = ref(storage, storagePath);

  // Normalize data URL if needed
  const formattedData = base64Data.startsWith("data:")
    ? base64Data
    : `data:image/jpeg;base64,${base64Data}`;

  await uploadString(storageRef, formattedData, "data_url");
  const downloadUrl = await getDownloadURL(storageRef);
  return { downloadUrl, storagePath };
}
