import React, { useState } from "react";
import { useDogDetections } from "./hooks/useDogDetections";
import { DogMonitoring } from "./components/DogMonitoring";
import { Analytics } from "./components/Analytics";

export const App: React.FC = () => {
  const [activeMainTab, setActiveMainTab] = useState<"monitoring" | "analytics">("monitoring");
  const { waitingDogs, rescuedDogs, loading, error, stats, rescueDog } = useDogDetections();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {/* Top Header */}
      <header className="bg-gradient-to-r from-slate-900 to-blue-950 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center p-1.5 shadow-inner">
              <svg className="w-full h-full text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">PawGuard AI</h1>
              <p className="text-xs text-blue-200">Monitor • Protect • Rescue</p>
            </div>
          </div>

          {/* Database Live Indicator */}
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-blue-100 bg-white/10 px-3 py-1 rounded-full">
              <span className={`w-2 h-2 rounded-full ${loading ? "bg-amber-400 animate-ping" : error ? "bg-red-400" : "bg-green-400"}`}></span>
              {loading ? "Connecting..." : error ? "Rules Check Needed" : "Firestore Live"}
            </span>
          </div>
        </div>

        {/* Two Main Navigation Tabs */}
        <div className="bg-white/5 border-t border-white/10">
          <div className="max-w-5xl mx-auto px-4 flex">
            <button
              onClick={() => setActiveMainTab("monitoring")}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-bold border-b-2 transition-all ${
                activeMainTab === "monitoring"
                  ? "border-blue-400 text-white bg-white/10"
                  : "border-transparent text-slate-300 hover:text-white"
              }`}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              Dog Monitoring
              {waitingDogs.length > 0 && (
                <span className="bg-amber-500 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded-full">
                  {waitingDogs.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveMainTab("analytics")}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-bold border-b-2 transition-all ${
                activeMainTab === "analytics"
                  ? "border-blue-400 text-white bg-white/10"
                  : "border-transparent text-slate-300 hover:text-white"
              }`}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              Analytics & Statistics
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="max-w-5xl mx-auto w-full px-4 py-6 flex-1">
        {activeMainTab === "monitoring" ? (
          <DogMonitoring
            waitingDogs={waitingDogs}
            rescuedDogs={rescuedDogs}
            loading={loading}
            error={error}
            onConfirmRescue={rescueDog}
          />
        ) : (
          <Analytics stats={stats} loading={loading} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-400">
        PawGuard AI • Connected to Firestore Project: <span className="font-mono text-slate-600 font-semibold">pawguard-54ad8</span> • Collection: <span className="font-mono text-slate-600 font-semibold">dog_detections</span>
      </footer>
    </div>
  );
};

export default App;
